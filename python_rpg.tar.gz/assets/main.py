from __future__ import annotations

import asyncio
import os
import sys


def report_loading(message: str) -> None:
    print(message)
    if sys.platform != "emscripten":
        return
    try:
        import platform

        platform.window.infobox.innerText = message
    except Exception:
        pass


report_loading("RPG: importing pygame")
try:
    import pygame  # noqa: F401
except ModuleNotFoundError as exc:
    raise SystemExit(
        "pygame is not installed. Run: cd python_rpg && venv/bin/python -m pip install -r requirements.txt"
    ) from exc


async def main(argv: list[str]) -> int:
    report_loading("RPG: preparing startup")
    smoke_test = "--smoke-test" in argv
    if smoke_test:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    report_loading("RPG: importing game")
    from rpg.game import RPGPrototype

    report_loading("RPG: creating game")
    game = RPGPrototype()
    if smoke_test:
        report_loading("RPG: running smoke test")
        game.run_smoke_test()
    else:
        report_loading("RPG: starting game loop")
        await game.run()
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main(sys.argv[1:]))
    if sys.platform != "emscripten":
        raise SystemExit(exit_code)
