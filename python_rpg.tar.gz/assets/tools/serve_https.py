from __future__ import annotations

import errno
import functools
import mimetypes
import ssl
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class ThreadingHTTPSServer(ThreadingHTTPServer):
    request_queue_size = 20
    daemon_threads = True

    def __init__(
        self,
        server_address: tuple[str, int],
        handler_class: type[SimpleHTTPRequestHandler],
        context: ssl.SSLContext,
    ) -> None:
        self.context = context
        super().__init__(server_address, handler_class)

    def get_request(self) -> tuple[ssl.SSLSocket, tuple[str, int]]:
        socket, address = super().get_request()
        socket.settimeout(10)
        return (
            self.context.wrap_socket(
                socket,
                server_side=True,
                do_handshake_on_connect=False,
            ),
            address,
        )

    def handle_error(self, request: object, client_address: tuple[str, int]) -> None:
        exc = sys.exc_info()[1]
        if isinstance(exc, ssl.SSLError):
            print(f"{client_address[0]}:{client_address[1]} TLS connection closed: {exc}", flush=True)
            return
        super().handle_error(request, client_address)


def main(argv: list[str]) -> int:
    if len(argv) != 4:
        print("Usage: python tools/serve_https.py <web-root> <port> <certfile> <keyfile>")
        return 2

    root = Path(argv[0]).resolve()
    port = int(argv[1])
    certfile = Path(argv[2]).resolve()
    keyfile = Path(argv[3]).resolve()

    mimetypes.add_type("application/wasm", ".wasm")
    mimetypes.add_type("application/gzip", ".gz")

    handler = functools.partial(SimpleHTTPRequestHandler, directory=str(root))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=certfile, keyfile=keyfile)
    try:
        server = ThreadingHTTPSServer(("0.0.0.0", port), handler, context)
    except OSError as exc:
        if exc.errno == errno.EADDRINUSE:
            print(f"Port {port} is already in use.")
            print("Stop the existing server with Ctrl+C, or use another port:")
            print(f"  tools/run_pygbag_https.sh <LAN_IP> {port + 1}")
            return 1
        raise

    print(f"Serving HTTPS on 0.0.0.0 port {port} from {root}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nHTTPS server stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
