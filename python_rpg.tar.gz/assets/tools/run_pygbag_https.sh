#!/usr/bin/env bash
set -eu

cd "$(dirname "$0")/.."

PYTHON="${PYTHON:-python3}"
PYGBAG="${PYGBAG:-pygbag}"
if [ -x venv/bin/python ]; then
    PYTHON="venv/bin/python"
fi
if [ -x venv/bin/pygbag ]; then
    PYGBAG="venv/bin/pygbag"
fi

LAN_IP="${1:-}"
PORT="${2:-${PORT:-8000}}"
CERT_DIR="build/https-cert"
CERT_FILE="${CERT_DIR}/server.pem"
KEY_FILE="${CERT_DIR}/key.pem"
if [ -z "$LAN_IP" ]; then
    LAN_IP="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"
fi
if [ -z "$LAN_IP" ]; then
    LAN_IP="$(hostname -I | awk '{print $1}')"
fi
if [ -z "$LAN_IP" ]; then
    echo "Could not detect LAN IP. Pass it explicitly, for example:"
    echo "  tools/run_pygbag_https.sh 192.168.3.75"
    exit 1
fi

mkdir -p "$CERT_DIR"
if [ -f key.pem ] && [ ! -f "$KEY_FILE" ]; then
    mv key.pem "$KEY_FILE"
fi
if [ -f server.pem ] && [ ! -f "$CERT_FILE" ]; then
    mv server.pem "$CERT_FILE"
fi

if [ ! -f "$KEY_FILE" ] || [ ! -f "$CERT_FILE" ]; then
    openssl req \
        -x509 \
        -newkey rsa:2048 \
        -nodes \
        -days 3650 \
        -keyout "$KEY_FILE" \
        -out "$CERT_FILE" \
        -subj "/CN=${LAN_IP}" \
        -addext "subjectAltName=IP:${LAN_IP},IP:127.0.0.1,DNS:localhost"
fi

echo "Starting pygbag HTTPS server"
echo "Open from another LAN device: https://${LAN_IP}:${PORT}/"
echo "If the browser shows a certificate warning, open Advanced and continue for LAN testing."

"$PYGBAG" --build .
"$PYTHON" tools/serve_https.py build/web "$PORT" "$CERT_FILE" "$KEY_FILE"
