from __future__ import annotations

import math
import random
import struct
import wave
from pathlib import Path

SAMPLE_RATE = 22050
MAX_AMPLITUDE = 32767
PROJECT_DIR = Path(__file__).resolve().parents[1]
AUDIO_DIR = PROJECT_DIR / "assets" / "audio"
SFX_DIR = AUDIO_DIR / "sfx"
BGM_DIR = AUDIO_DIR / "bgm"
WAV_SUFFIX = "." + "wav"


def main() -> int:
    SFX_DIR.mkdir(parents=True, exist_ok=True)
    BGM_DIR.mkdir(parents=True, exist_ok=True)

    written_paths = [
        write_sfx(audio_name("cursor"), [(740, 0.035), (980, 0.035)], 0.28, "square"),
        write_sfx(audio_name("confirm"), [(880, 0.05), (1320, 0.08)], 0.32, "triangle"),
        write_sfx(audio_name("cancel"), [(620, 0.05), (420, 0.09)], 0.28, "square"),
        write_sfx(audio_name("talk"), [(900, 0.025), (760, 0.025), (900, 0.025)], 0.2, "triangle"),
        write_noise_sfx(audio_name("attack"), 0.14, 0.44),
        write_noise_sfx(audio_name("damage"), 0.2, 0.36, descending=True),
        write_sfx(audio_name("heal"), [(660, 0.08), (880, 0.08), (1175, 0.15)], 0.24, "sine"),
        write_sfx(audio_name("battle_start"), [(220, 0.08), (330, 0.08), (440, 0.16)], 0.34, "saw"),
        write_sfx(audio_name("victory"), [(523, 0.12), (659, 0.12), (784, 0.12), (1046, 0.28)], 0.32, "triangle"),
        write_bgm(audio_name("village"), [523, 659, 784, 659, 587, 698, 880, 698], tempo=0.28, volume=0.18),
        write_bgm(audio_name("random_dungeon"), [220, 247, 262, 196, 220, 175, 196, 165], tempo=0.36, volume=0.15),
        write_bgm(audio_name("symbol_dungeon"), [196, 233, 262, 233, 175, 208, 247, 208], tempo=0.32, volume=0.16),
        write_bgm(audio_name("battle"), [330, 392, 440, 523, 494, 440, 392, 330], tempo=0.18, volume=0.19),
    ]

    for path in written_paths:
        print(path)
    return 0


def audio_name(stem: str) -> str:
    return f"{stem}{WAV_SUFFIX}"


def write_sfx(
    filename: str,
    notes: list[tuple[float, float]],
    volume: float,
    waveform: str,
) -> Path:
    samples: list[float] = []
    for frequency, duration in notes:
        samples.extend(tone(frequency, duration, volume, waveform))
    path = SFX_DIR / filename
    write_wav(path, samples)
    return path


def write_noise_sfx(
    filename: str,
    duration: float,
    volume: float,
    descending: bool = False,
) -> Path:
    sample_count = int(SAMPLE_RATE * duration)
    samples = []
    for index in range(sample_count):
        progress = index / max(1, sample_count - 1)
        envelope = (1.0 - progress) ** 1.7
        pitch = 1.0 - progress if descending else progress
        wave_value = random.uniform(-1.0, 1.0) * 0.65
        wave_value += math.sin(2 * math.pi * (160 + 520 * pitch) * index / SAMPLE_RATE) * 0.35
        samples.append(wave_value * envelope * volume)
    path = SFX_DIR / filename
    write_wav(path, samples)
    return path


def write_bgm(filename: str, melody: list[float], tempo: float, volume: float) -> Path:
    samples: list[float] = []
    bass_notes = [frequency / 2 for frequency in melody]
    for loop_index in range(4):
        for index, frequency in enumerate(melody):
            bass = bass_notes[(index + loop_index) % len(bass_notes)]
            melody_samples = tone(frequency, tempo, volume, "triangle")
            bass_samples = tone(bass, tempo, volume * 0.45, "square")
            harmony_samples = tone(frequency * 1.5, tempo, volume * 0.22, "sine")
            samples.extend(mix_samples(melody_samples, bass_samples, harmony_samples))
    path = BGM_DIR / filename
    write_wav(path, samples)
    return path


def tone(frequency: float, duration: float, volume: float, waveform: str) -> list[float]:
    sample_count = int(SAMPLE_RATE * duration)
    samples = []
    for index in range(sample_count):
        t = index / SAMPLE_RATE
        progress = index / max(1, sample_count - 1)
        envelope = min(1.0, progress * 16) * min(1.0, (1.0 - progress) * 10)
        phase = 2 * math.pi * frequency * t
        if waveform == "square":
            value = 1.0 if math.sin(phase) >= 0 else -1.0
        elif waveform == "triangle":
            value = 2.0 * abs(2.0 * ((frequency * t) % 1.0) - 1.0) - 1.0
        elif waveform == "saw":
            value = 2.0 * ((frequency * t) % 1.0) - 1.0
        else:
            value = math.sin(phase)
        samples.append(value * envelope * volume)
    return samples


def mix_samples(*tracks: list[float]) -> list[float]:
    mixed = []
    for frame in zip(*tracks):
        mixed.append(sum(frame) / max(1, len(frame)))
    return mixed


def write_wav(path: Path, samples: list[float]) -> None:
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(SAMPLE_RATE)
        frames = bytearray()
        for sample in samples:
            clamped = max(-1.0, min(1.0, sample))
            frames.extend(struct.pack("<h", int(clamped * MAX_AMPLITUDE)))
        wav.writeframes(bytes(frames))


if __name__ == "__main__":
    raise SystemExit(main())
