from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

PROJECT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_DIR))

import pygame

from rpg.tile_images import TILE_ASSET_DIR, save_tile_images


def main() -> int:
    pygame.init()
    written_paths = save_tile_images(TILE_ASSET_DIR)
    for path in written_paths:
        print(path)
    pygame.quit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
