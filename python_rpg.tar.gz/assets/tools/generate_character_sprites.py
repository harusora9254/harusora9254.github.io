from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

PROJECT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_DIR))

import pygame

from rpg.character_sprites import ASSET_DIR, create_preview_sheet, save_sprite_sheets


def main() -> int:
    pygame.init()
    written_paths = save_sprite_sheets(ASSET_DIR)
    preview_path = ASSET_DIR / "preview_all_characters.png"
    pygame.image.save(create_preview_sheet(ASSET_DIR), str(preview_path))
    for path in [*written_paths, preview_path]:
        print(path)
    pygame.quit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
