# Python RPG Prototype

Pygameで作る2D RPGプロトタイプです。
Python学習を主目的にしつつ、最終的には pygbag でブラウザゲームとして公開できる形を目指しています。

## 現在できること

```text
タイル単位のマップ移動と滑らかな移動補間
方向キー / WASD の長押し移動
スマホ向けの画面外バーチャルパッド
広いマップの自動スクロール
村マップとNPC会話
ランダムエンカウント洞窟
シンボルエンカウント洞窟
メニュー画面
2人パーティのターン制戦闘
BGM / 効果音
```

## セットアップ

Raspberry Pi 上で作業する想定です。

```bash
cd /home/yut25/Playground/python_rpg
python3 -m venv venv
source venv/bin/activate
python -m pip install -r requirements.txt
```

2回目以降は `source venv/bin/activate` だけで同じvenvを再利用できます。

## 通常のPygame実行

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python main.py
```

SSHだけではPC側にPygame画面は出ません。通常Pygameの画面を確認する場合は、Raspberry Pi の画面、VNC、またはGUI転送環境を使います。

## ブラウザで確認

### PCからSSHトンネルで確認

PC側でSSHトンネルを開きます。

```bash
ssh -L 8000:127.0.0.1:8000 yut25@192.168.3.75
```

Raspberry Pi側では以下を実行します。

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
pygbag .
```

PCブラウザで開きます。

```text
http://localhost:8000/
```

### スマホなどLAN内の別端末から確認

スマホではブラウザの制約により、LAN内テストでもHTTPS配信が安定します。
Python 3.13では pygbag 内蔵の `--ssl` が使えないため、`pygbag --build` 後に専用のHTTPSサーバーで配信します。

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
tools/run_pygbag_https.sh
```

表示されたURLをスマホで開きます。

```text
https://192.168.3.75:8000/
```

8000番が使用中の場合は、ポートを指定します。

```bash
tools/run_pygbag_https.sh 192.168.3.75 8001
```

自己署名証明書の警告が出た場合は、LAN内テスト用として詳細表示から続行します。
GitHub Pagesで公開した場合は正式なHTTPS配信になるため、この証明書は不要です。

## 操作

```text
矢印キー / WASD: 移動、選択
M: メニューを開く / 閉じる
Enter / Space: 決定、NPCに話しかける
Esc / Q: マップ画面では終了、メニュー画面では戻る
```

ブラウザ版では、PCブラウザは右上の `PAD` ボタンからバーチャルパッドを表示できます。
スマホでは自動的に表示されます。

```text
十字キー: 移動、選択
A: 決定、NPCに話しかける
B: キャンセル、非戦闘時はメニューを開く
```

## ディレクトリ構成

```text
python_rpg/
  main.py
  requirements.txt
  rpg/
    audio_manager.py       音声読み込みと再生
    battle_system.py       戦闘ロジック
    battle_screen.py       戦闘画面描画
    character_sprites.py   キャラクター画像読み込み
    constants.py           画面サイズ、色、敵データなど
    fonts.py               日本語/英数字フォント読み込み
    game.py                メインゲーム制御
    map_loader.py          JSONマップ読み込み
    map_screen.py          マップ画面描画
    menu_screen.py         メニュー画面描画
    models.py              データモデル
    screen_utils.py        描画ヘルパー
    tile_images.py         タイル画像読み込み
    virtual_controller.py  ブラウザ/スマホ向け仮想パッド
  data/
    maps/
      village.json
      random_dungeon.json
      symbol_dungeon.json
  assets/
    fonts/
      DroidSansFallbackFull.ttf
    images/
      characters/
      tiles/
    audio/
      sfx/
      bgm/
  tools/
    generate_audio.py
    generate_character_sprites.py
    generate_tile_images.py
    run_pygbag_https.sh
    serve_https.py
  docs/
    editing_guide.md
```

## 画像と音声

キャラクター画像は `assets/images/characters/`、タイル画像は `assets/images/tiles/` から読み込みます。
音声は通常Pygameでは `.wav`、ブラウザ版では `*-pygbag.ogg` を優先して読み込みます。

素材を再生成する場合:

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python tools/generate_character_sprites.py
python tools/generate_tile_images.py
python tools/generate_audio.py
```

## 編集手順書

マップ編集、敵の追加、ステータス調整、画像・音声差し替えの手順は [docs/editing_guide.md](docs/editing_guide.md) にまとめています。

## 確認用コマンド

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python main.py --smoke-test
pygbag --build .
```
