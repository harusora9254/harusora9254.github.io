# RPG編集手順書

この手順書は、自分でマップを編集したり、敵を追加したり、主人公たちのステータスを調整するためのガイドです。
基本的には `data/maps/` のJSONと、`rpg/constants.py`、`rpg/game.py` を編集すればゲーム内容を変えられます。

## まず確認する場所

```text
python_rpg/
  data/maps/                 マップJSON
    village.json             村
    random_dungeon.json      ランダムエンカウント洞窟
    symbol_dungeon.json      シンボルエンカウント洞窟
  rpg/
    constants.py             敵ステータス、移動速度、通行不可タイル
    game.py                  初期パーティ、初期アイテム、所持金
    character_sprites.py     敵の種類と表示スプライトの対応
    audio_manager.py         マップIDとBGMファイルの対応
  assets/
    images/characters/       キャラクター画像
    images/tiles/            タイル画像
    audio/                   効果音、BGM
  tools/                     画像・音声の生成スクリプト
```

## マップを編集する

マップは `python_rpg/data/maps/*.json` にあります。
座標は左上が `(0, 0)` です。右に進むと `x` が増え、下に進むと `y` が増えます。

マップJSONの基本形は以下です。

```json
{
  "id": "sample_map",
  "name": "サンプルマップ",
  "width": 30,
  "height": 20,
  "base_tile": "grass",
  "start": {
    "x": 5,
    "y": 5
  },
  "encounter_type": "none",
  "floor_tiles": [],
  "object_tiles": [],
  "npcs": [],
  "enemies": [],
  "exits": []
}
```

`id` はファイル名と合わせます。
たとえば `sample_map.json` なら `"id": "sample_map"` にします。

## タイルのレイヤ

このゲームのマップは、主に2段階のレイヤで編集します。

```text
L1: floor_tiles
床タイルです。草、道、水、壁、洞窟床、洞窟壁、出口などを置きます。
透明部分はありません。

L2: object_tiles
床の上に置く障害物です。木、岩などを置きます。
透明部分があります。
```

使えるタイルIDは以下です。

```text
L1:
grass
path
water
wall
dungeon_floor
dungeon_wall
exit

L2:
tree
rock
```

初期状態では、以下のタイルは通行できません。

```text
wall
water
tree
dungeon_wall
```

通行不可タイルを変更したい場合は、`rpg/constants.py` の `BLOCKED_TILES` を編集します。

## タイルを置く

広い範囲に置く場合は `rect` を使います。
書式は `[x, y, 横幅, 高さ]` です。

```json
{
  "tile": "path",
  "rect": [3, 10, 12, 2]
}
```

1マスずつ置く場合は `points` を使います。

```json
{
  "tile": "water",
  "points": [[8, 5], [9, 5], [10, 5]]
}
```

L1に道を置き、L2に木を置く例です。

```json
"floor_tiles": [
  {
    "tile": "path",
    "rect": [2, 8, 20, 3]
  }
],
"object_tiles": [
  {
    "tile": "tree",
    "points": [[4, 4], [5, 4], [6, 4]]
  }
]
```

## NPCを追加する

NPCは `npcs` に追加します。

```json
{
  "id": "villager_04",
  "name": "村人",
  "x": 12,
  "y": 9,
  "dialog": [
    "ここは小さな村です。",
    "北には洞窟があります。"
  ]
}
```

`dialog` は複数行にできます。
プレイヤーが向いている方向の1マス先にNPCがいると、EnterまたはSpaceで会話できます。

## マップ間の移動を作る

マップ移動は `exits` に追加します。

```json
{
  "x": 25,
  "y": 2,
  "target": "random_dungeon",
  "target_x": 4,
  "target_y": 4,
  "message": "ランダム洞窟に入りました。"
}
```

`target` は移動先マップの `id` です。
上の例では、現在のマップの `(25, 2)` に乗ると `random_dungeon.json` の `(4, 4)` に移動します。

出口タイルを見た目でも分かるようにしたい場合は、`floor_tiles` にも `exit` を置きます。

```json
{
  "tile": "exit",
  "points": [[25, 2]]
}
```

## 新しいマップを作る

1. `python_rpg/data/maps/` に既存マップをコピーします。
2. ファイル名を `new_map.json` のように変更します。
3. JSON内の `"id"` も `"new_map"` に変更します。
4. `width`、`height`、`base_tile`、`start` を決めます。
5. `floor_tiles` と `object_tiles` を編集します。
6. 既存マップの `exits` から新しいマップへ移動できるようにします。
7. 新しいマップから戻るための `exits` も作ります。

新しいマップ専用BGMを使いたい場合は、`rpg/audio_manager.py` の `BGM_IDS` にマップIDを追加します。

```python
BGM_IDS = ("village", "random_dungeon", "symbol_dungeon", "battle", "new_map")
```

通常Pygame用の `new_map.wav` は `python_rpg/assets/audio/bgm/` に置きます。
ブラウザ版でも鳴らす場合は `new_map-pygbag.ogg` も同じ場所に置きます。

## 敵を作成する

敵ステータスは `python_rpg/rpg/constants.py` の `ENEMY_DATA` にあります。

```python
ENEMY_DATA = {
    "スライム": {
        "max_hp": 35,
        "attack": 8,
        "defense": 4,
        "speed": 6,
        "exp": 5,
    },
}
```

新しい敵を追加する例です。

```python
ENEMY_DATA = {
    "スライム": {
        "max_hp": 35,
        "attack": 8,
        "defense": 4,
        "speed": 6,
        "exp": 5,
    },
    "オーク": {
        "max_hp": 80,
        "attack": 16,
        "defense": 9,
        "speed": 7,
        "exp": 18,
    },
}
```

各項目の意味は以下です。

```text
max_hp   最大HP
attack   攻撃力
defense  防御力
speed    行動順に使う素早さ
exp      倒したときにもらえる経験値
```

現在の戦闘処理では、敵のMPやスキルは使っていません。
まずはHP、攻撃、防御、素早さ、経験値を調整すると分かりやすいです。

## ランダムエンカウントを設定する

ランダムエンカウントのマップでは、JSONに以下を設定します。

```json
"encounter_type": "random",
"random_encounters": ["スライム", "コウモリ", "ゴブリン"],
"encounter_rate": 0.14
```

`random_encounters` には、`ENEMY_DATA` に登録済みの敵名を書きます。
`encounter_rate` は歩いたときに戦闘へ入る確率です。
数値を上げるほど戦闘が多くなります。

## シンボルエンカウントを設定する

シンボルエンカウントの敵は、マップJSONの `enemies` に追加します。

```json
{
  "kind": "ゴブリン",
  "x": 18,
  "y": 10,
  "move_style": "random"
}
```

`kind` は `ENEMY_DATA` に登録済みの敵名です。
`move_style` は以下を使います。

```text
static  動かない
random  ランダムに歩く
```

敵の移動速度を個別に変えたい場合は `move_duration_ms` を追加します。
小さいほど速く動きます。

```json
{
  "kind": "ゴブリン",
  "x": 18,
  "y": 10,
  "move_style": "random",
  "move_duration_ms": 180
}
```

シンボル敵は、通行不可タイル、NPC、他の敵、プレイヤーがいる場所へは移動しません。

## 敵グラフィックを切り替える

敵名と表示画像の対応は `python_rpg/rpg/character_sprites.py` の `enemy_sprite_id` で決めています。

```python
def enemy_sprite_id(kind: str) -> str:
    if kind == "ゴブリン":
        return STRONG_ENEMY
    return WEAK_ENEMY
```

強そうな見た目にしたい敵を増やす場合は、条件を追加します。

```python
def enemy_sprite_id(kind: str) -> str:
    if kind in ("ゴブリン", "オーク", "魔王"):
        return STRONG_ENEMY
    return WEAK_ENEMY
```

## 主人公たちのステータスを変更する

初期パーティは `python_rpg/rpg/game.py` の `self.party` にあります。

```python
self.party = [
    Combatant("勇者", 120, 120, 20, 20, 18, 12, 12, "強撃", 5),
    Combatant("僧侶", 90, 90, 35, 35, 10, 9, 14, "ヒール", 5),
]
```

`Combatant` の並びは以下です。

```text
Combatant(
    名前,
    最大HP,
    現在HP,
    最大MP,
    現在MP,
    攻撃力,
    防御力,
    素早さ,
    スキル名,
    スキル消費MP,
)
```

勇者のHPと攻撃力を上げる例です。

```python
Combatant("勇者", 160, 160, 20, 20, 25, 12, 12, "強撃", 5)
```

最大HPと現在HP、最大MPと現在MPは同じ値にしておくと、ゲーム開始時に全回復状態になります。

## 初期アイテム・所持金・経験値を変更する

同じく `python_rpg/rpg/game.py` にあります。

```python
self.inventory = {"薬草": 3}
self.gold = 0
self.exp = 0
```

薬草を10個にする例です。

```python
self.inventory = {"薬草": 10}
```

現時点では、戦闘中に使えるアイテムは薬草だけです。

## キャラクター画像を差し替える

キャラクター画像は `python_rpg/assets/images/characters/` にあります。

```text
hero.png          主人公
villager.png      村人
enemy_weak.png    弱敵
enemy_strong.png  強敵
```

画像サイズは1ファイル `128x128` です。
32x32のフレームを、横4枚、縦4方向で並べます。

```text
1行目: 下向き
2行目: 左向き
3行目: 右向き
4行目: 上向き

各行:
1, 2, 3, 4フレーム
```

画像をプログラムで再生成する場合は、以下を実行します。

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python tools/generate_character_sprites.py
```

自作画像に差し替える場合も、ファイル名とサイズを合わせると、そのまま読み込めます。

## タイル画像を差し替える

タイル画像は `python_rpg/assets/images/tiles/` にあります。
1タイルは `32x32` です。

```text
l1_grass.png          grass
l1_path.png           path
l1_water.png          water
l1_wall.png           wall
l1_dungeon_floor.png  dungeon_floor
l1_dungeon_wall.png   dungeon_wall
l1_exit.png           exit
l2_tree.png           tree
l2_rock.png           rock
```

L1画像は透明なし、L2画像は透明ありで作ると扱いやすいです。

タイル画像をプログラムで再生成する場合は、以下を実行します。

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python tools/generate_tile_images.py
```

## 効果音・BGMを再生成する

現在の音声はPythonで生成した簡易WAVです。
ブラウザ版では `*-pygbag.ogg` があればそちらを優先して読み込みます。

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python tools/generate_audio.py
```

自作音源に差し替える場合は、同じファイル名で以下に置きます。

```text
python_rpg/assets/audio/sfx/
python_rpg/assets/audio/bgm/
```

## 編集後の確認

JSONやPythonを編集したら、まず構文チェックをします。

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python -m py_compile main.py rpg/*.py tools/*.py
```

画面を一通り描画できるか確認します。

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python main.py --smoke-test
```

最後に実際に起動します。

```bash
cd /home/yut25/Playground/python_rpg
source venv/bin/activate
python main.py
```

## よくあるミス

JSONの末尾カンマに注意します。
最後の項目の後ろに `,` を付けると読み込みエラーになります。

```json
{
  "x": 4,
  "y": 4
}
```

マップIDとファイル名を一致させます。
`new_map.json` なら `"id": "new_map"` にします。

`exits` の `target` は、移動先マップの `id` と一致させます。
存在しないIDを書くと、移動時にマップを読み込めません。

敵名は `ENEMY_DATA` に登録してから、マップJSONに書きます。
未登録の敵名を書くと、戦闘開始時に敵データを取得できません。

プレイヤーの開始位置、NPC、敵、出口は、通行不可タイルの上に置かないようにします。
特に `wall`、`water`、`tree`、`dungeon_wall` の上は避けます。

新しい画像に差し替える場合は、サイズとファイル名を合わせます。
キャラクターは `128x128`、タイルは `32x32` が現在の前提です。

## おすすめの編集順

最初はこの順番で触ると、壊れた場所を見つけやすいです。

```text
1. village.json のNPC会話を変える
2. village.json に木や岩を1つ追加する
3. constants.py で敵ステータスを少し変える
4. random_dungeon.json の encounter_rate を変える
5. symbol_dungeon.json に敵を1体追加する
6. 新しいマップJSONを1つ作る
```
