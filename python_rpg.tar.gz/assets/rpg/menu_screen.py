from __future__ import annotations

import pygame

from rpg.constants import COLOR_ACCENT, COLOR_BG, COLOR_GOLD, COLOR_MUTED, COLOR_PANEL, COLOR_TEXT
from rpg.screen_utils import draw_text


class MenuScreen:
    def __init__(self, game: object) -> None:
        self.game = game

    def draw(self) -> None:
        game = self.game
        game.screen.fill(COLOR_BG)
        draw_text(game.screen, "メニュー", 42, 38, game.big_font, COLOR_TEXT)

        left_panel = pygame.Rect(40, 100, 220, 300)
        right_panel = pygame.Rect(290, 100, 470, 390)
        pygame.draw.rect(game.screen, COLOR_PANEL, left_panel, border_radius=8)
        pygame.draw.rect(game.screen, COLOR_PANEL, right_panel, border_radius=8)

        for index, item in enumerate(game.menu_items):
            y = 132 + index * 54
            selected = index == game.menu_index
            if selected:
                pygame.draw.rect(game.screen, COLOR_ACCENT, pygame.Rect(58, y - 10, 180, 38), border_radius=6)
            color = COLOR_TEXT if selected else COLOR_MUTED
            draw_text(game.screen, item, 78, y, game.font, color)

        selected_item = game.menu_items[game.menu_index]
        if selected_item == "ステータス":
            self.draw_status_panel(right_panel)
        elif selected_item == "アイテム":
            self.draw_items_panel(right_panel)
        else:
            draw_text(game.screen, "マップに戻ります。", right_panel.x + 28, right_panel.y + 34, game.font, COLOR_TEXT)

    def draw_status_panel(self, panel: pygame.Rect) -> None:
        game = self.game
        draw_text(game.screen, "パーティ", panel.x + 28, panel.y + 28, game.big_font, COLOR_TEXT)
        y = panel.y + 88
        for member in game.party:
            draw_text(game.screen, member.name, panel.x + 32, y, game.font, COLOR_TEXT)
            draw_text(game.screen, f"HP {member.hp}/{member.max_hp}", panel.x + 150, y, game.font, COLOR_TEXT)
            draw_text(game.screen, f"MP {member.mp}/{member.max_mp}", panel.x + 290, y, game.font, COLOR_MUTED)
            draw_text(game.screen, f"攻撃 {member.attack}", panel.x + 150, y + 30, game.small_font, COLOR_MUTED)
            draw_text(game.screen, f"防御 {member.defense}", panel.x + 240, y + 30, game.small_font, COLOR_MUTED)
            draw_text(game.screen, f"速さ {member.speed}", panel.x + 330, y + 30, game.small_font, COLOR_MUTED)
            y += 86

        draw_text(game.screen, f"所持金: {game.gold}", panel.x + 32, panel.y + 320, game.font, COLOR_GOLD)
        draw_text(game.screen, f"経験値: {game.exp}", panel.x + 170, panel.y + 320, game.font, COLOR_TEXT)
        draw_text(game.screen, f"現在地: {game.current_map.name}", panel.x + 32, panel.y + 350, game.font, COLOR_MUTED)

    def draw_items_panel(self, panel: pygame.Rect) -> None:
        game = self.game
        draw_text(game.screen, "アイテム", panel.x + 28, panel.y + 28, game.big_font, COLOR_TEXT)
        y = panel.y + 92
        if not game.inventory:
            draw_text(game.screen, "アイテムを持っていません。", panel.x + 32, y, game.font, COLOR_MUTED)
            return
        for item_name, count in game.inventory.items():
            draw_text(game.screen, item_name, panel.x + 32, y, game.font, COLOR_TEXT)
            draw_text(game.screen, f"x{count}", panel.x + 180, y, game.font, COLOR_MUTED)
            y += 36
