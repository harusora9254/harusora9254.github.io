from __future__ import annotations

import pygame

from rpg.constants import (
    COLOR_ACCENT,
    COLOR_BG,
    COLOR_GOLD,
    COLOR_MUTED,
    COLOR_PANEL,
    COLOR_PANEL_ALT,
    COLOR_TEXT,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
)
from rpg.screen_utils import draw_text


class MenuScreen:
    def __init__(self, game: object) -> None:
        self.game = game

    def draw(self) -> None:
        game = self.game
        game.screen.fill(COLOR_BG)
        if game.menu_mode == "status_detail":
            self.draw_member_status_screen()
            return
        if game.menu_mode == "item_list":
            self.draw_item_list_screen()
            return

        draw_text(game.screen, "メニュー", 42, 38, game.big_font, COLOR_TEXT)

        left_panel = pygame.Rect(40, 100, 220, 300)
        right_panel = pygame.Rect(290, 100, 470, 390)
        pygame.draw.rect(game.screen, COLOR_PANEL, left_panel, border_radius=8)
        pygame.draw.rect(game.screen, COLOR_PANEL, right_panel, border_radius=8)

        for index, item in enumerate(game.menu_items):
            y = 132 + index * 54
            selected = index == game.menu_index
            if selected:
                pygame.draw.rect(game.screen, COLOR_ACCENT, pygame.Rect(58, y - 10, 180, 38), border_radius=6)
            color = COLOR_TEXT if selected else COLOR_MUTED
            draw_text(game.screen, item, 78, y, game.font, color)

        selected_item = game.menu_items[game.menu_index]
        if selected_item == "ステータス":
            self.draw_status_panel(right_panel)
        elif selected_item == "アイテム":
            self.draw_items_panel(right_panel)
        else:
            draw_text(game.screen, "マップに戻ります。", right_panel.x + 28, right_panel.y + 34, game.font, COLOR_TEXT)

    def draw_status_panel(self, panel: pygame.Rect) -> None:
        game = self.game
        draw_text(game.screen, "ステータス", panel.x + 28, panel.y + 28, game.big_font, COLOR_TEXT)
        y = panel.y + 88
        for index, member in enumerate(game.party):
            selected = game.menu_mode == "status_list" and index == game.status_member_index
            if selected:
                row = pygame.Rect(panel.x + 20, y - 10, panel.width - 40, 50)
                pygame.draw.rect(game.screen, COLOR_PANEL_ALT, row, border_radius=6)
            draw_text(game.screen, member.name, panel.x + 32, y, game.font, COLOR_TEXT)
            draw_text(game.screen, f"HP {member.hp}/{member.max_hp}", panel.x + 150, y, game.font, COLOR_TEXT)
            draw_text(game.screen, f"MP {member.mp}/{member.max_mp}", panel.x + 290, y, game.font, COLOR_MUTED)
            y += 64

        draw_text(game.screen, f"所持金: {game.gold}", panel.x + 32, panel.y + 320, game.font, COLOR_GOLD)
        draw_text(game.screen, f"経験値: {game.exp}", panel.x + 170, panel.y + 320, game.font, COLOR_TEXT)
        draw_text(game.screen, f"現在地: {game.current_map.name}", panel.x + 32, panel.y + 350, game.font, COLOR_MUTED)

    def draw_member_status_screen(self) -> None:
        game = self.game
        member = game.party[game.status_member_index]
        panel = pygame.Rect(40, 36, SCREEN_WIDTH - 80, SCREEN_HEIGHT - 72)
        pygame.draw.rect(game.screen, COLOR_PANEL, panel, border_radius=8)

        draw_text(game.screen, "ステータス", panel.x + 28, panel.y + 24, game.font, COLOR_MUTED)
        draw_text(game.screen, member.name, panel.x + 28, panel.y + 58, game.big_font, COLOR_TEXT)
        draw_text(game.screen, f"HP {member.hp}/{member.max_hp}", panel.x + 360, panel.y + 62, game.font, COLOR_TEXT)
        draw_text(game.screen, f"MP {member.mp}/{member.max_mp}", panel.x + 540, panel.y + 62, game.font, COLOR_MUTED)

        base_panel = pygame.Rect(panel.x + 28, panel.y + 124, 320, 276)
        battle_panel = pygame.Rect(panel.x + 384, panel.y + 124, 300, 276)
        skill_panel = pygame.Rect(panel.x + 28, panel.y + 424, panel.width - 56, 92)
        pygame.draw.rect(game.screen, COLOR_PANEL_ALT, base_panel, border_radius=6)
        pygame.draw.rect(game.screen, COLOR_PANEL_ALT, battle_panel, border_radius=6)
        pygame.draw.rect(game.screen, COLOR_PANEL_ALT, skill_panel, border_radius=6)

        draw_text(game.screen, "基本能力", base_panel.x + 20, base_panel.y + 18, game.font, COLOR_TEXT)
        draw_text(game.screen, "戦闘補正", battle_panel.x + 20, battle_panel.y + 18, game.font, COLOR_TEXT)

        left_x = base_panel.x + 24
        y = base_panel.y + 62
        self.draw_stat_line("攻撃力", member.attack, left_x, y)
        y += 30
        self.draw_stat_line("防御力", member.defense, left_x, y)
        y += 30
        self.draw_stat_line("魔法攻撃", member.magic_attack, left_x, y)
        y += 30
        self.draw_stat_line("魔法防御", member.magic_defense, left_x, y)
        y += 30
        self.draw_stat_line("素早さ", member.speed, left_x, y)
        y += 30
        self.draw_stat_line("運", member.luck, left_x, y)

        right_x = battle_panel.x + 24
        y = battle_panel.y + 62
        self.draw_stat_line("命中率", f"{int(member.hit_rate * 100)}%", right_x, y)
        y += 30
        self.draw_stat_line("回避率", f"{int(member.evasion_rate * 100)}%", right_x, y)
        y += 30
        self.draw_stat_line("会心率", f"{int(member.critical_rate * 100)}%", right_x, y)
        y += 30
        self.draw_stat_line("会心回避", f"{int(member.critical_evasion_rate * 100)}%", right_x, y)
        y += 30
        self.draw_stat_line("狙われ率", f"{member.target_rate:.1f}", right_x, y)

        skill = member.primary_skill()
        draw_text(game.screen, "スキル", skill_panel.x + 20, skill_panel.y + 18, game.font, COLOR_TEXT)
        if skill is not None:
            skill_text = f"{skill.name} / MP {skill.mp_cost} / {skill.type}"
            draw_text(game.screen, skill_text, skill_panel.x + 120, skill_panel.y + 20, game.font, COLOR_MUTED)
            draw_text(
                game.screen,
                f"属性 {skill.element} / 対象 {skill.target} / 倍率 {skill.power:.1f}",
                skill_panel.x + 120,
                skill_panel.y + 52,
                game.small_font,
                COLOR_MUTED,
            )

    def draw_stat_line(self, label: str, value: object, x: int, y: int) -> None:
        game = self.game
        draw_text(game.screen, label, x, y, game.small_font, COLOR_MUTED)
        draw_text(game.screen, str(value), x + 100, y, game.small_font, COLOR_TEXT)

    def draw_items_panel(self, panel: pygame.Rect) -> None:
        game = self.game
        draw_text(game.screen, "アイテム", panel.x + 28, panel.y + 28, game.big_font, COLOR_TEXT)
        if not game.inventory:
            draw_text(game.screen, "アイテムを持っていません。", panel.x + 32, panel.y + 92, game.font, COLOR_MUTED)
            return
        draw_text(game.screen, "決定で一覧を開きます。", panel.x + 32, panel.y + 92, game.font, COLOR_TEXT)
        draw_text(game.screen, f"所持種類: {len(game.inventory)}", panel.x + 32, panel.y + 132, game.font, COLOR_MUTED)

    def draw_item_list_screen(self) -> None:
        game = self.game
        panel = pygame.Rect(40, 36, SCREEN_WIDTH - 80, SCREEN_HEIGHT - 72)
        pygame.draw.rect(game.screen, COLOR_PANEL, panel, border_radius=8)
        draw_text(game.screen, "アイテム", panel.x + 28, panel.y + 28, game.big_font, COLOR_TEXT)

        if not game.inventory:
            draw_text(game.screen, "アイテムを持っていません。", panel.x + 32, panel.y + 106, game.font, COLOR_MUTED)
            return

        y = panel.y + 100
        for index, (item_name, count) in enumerate(game.inventory.items()):
            selected = index == game.item_index
            if selected:
                row = pygame.Rect(panel.x + 24, y - 10, panel.width - 48, 44)
                pygame.draw.rect(game.screen, COLOR_PANEL_ALT, row, border_radius=6)
            draw_text(game.screen, item_name, panel.x + 44, y, game.font, COLOR_TEXT)
            draw_text(game.screen, f"x{count}", panel.right - 128, y, game.font, COLOR_MUTED)
            y += 50
