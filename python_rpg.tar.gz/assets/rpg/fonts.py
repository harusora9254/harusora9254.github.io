from __future__ import annotations

from pathlib import Path

import pygame

ASSET_FONT_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"

FONT_CANDIDATES = [
    ASSET_FONT_DIR / "DroidSansFallbackFull.ttf",
    Path("/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf"),
    Path("/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc"),
    Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
]

LATIN_FONT_CANDIDATES = [
    Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    Path("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"),
    Path("/usr/share/fonts/truetype/freefont/FreeSans.ttf"),
]


class GameFont:
    def __init__(self, primary_path: Path | None, latin_path: Path | None, size: int) -> None:
        self.primary = pygame.font.Font(str(primary_path), size) if primary_path else pygame.font.Font(None, size)
        self.latin = pygame.font.Font(str(latin_path), size) if latin_path else pygame.font.Font(None, size)

    def render(
        self,
        text: str,
        antialias: bool,
        color: tuple[int, int, int],
    ) -> pygame.Surface:
        if not text:
            return pygame.Surface((1, self.primary.get_height()), pygame.SRCALPHA)

        parts = []
        width = 0
        baseline = max(self.primary.get_ascent(), self.latin.get_ascent())
        height = max(self.primary.get_height(), self.latin.get_height())

        for char in text:
            font = self.latin if uses_latin_font(char) else self.primary
            surface = font.render(char, antialias, color)
            parts.append((surface, font))
            width += surface.get_width()

        text_surface = pygame.Surface((max(1, width), height), pygame.SRCALPHA)
        x = 0
        for surface, font in parts:
            y = baseline - font.get_ascent()
            text_surface.blit(surface, (x, y))
            x += surface.get_width()
        return text_surface


def load_font(size: int) -> GameFont:
    return GameFont(first_existing_path(FONT_CANDIDATES), first_existing_path(LATIN_FONT_CANDIDATES), size)


def first_existing_path(paths: list[Path]) -> Path | None:
    for path in paths:
        if path.exists():
            return path
    return None


def uses_latin_font(char: str) -> bool:
    return " " <= char <= "~"
