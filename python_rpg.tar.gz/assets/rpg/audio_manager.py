from __future__ import annotations

import sys
from pathlib import Path

import pygame

AUDIO_DIR = Path(__file__).resolve().parent.parent / "assets" / "audio"
SFX_DIR = AUDIO_DIR / "sfx"
BGM_DIR = AUDIO_DIR / "bgm"

MIXER_FREQUENCY = 44100
MIXER_SIZE = -16
MIXER_CHANNELS = 2
MIXER_BUFFER = 4096

SFX_IDS = (
    "cursor",
    "confirm",
    "cancel",
    "talk",
    "attack",
    "damage",
    "heal",
    "battle_start",
    "victory",
)

BGM_IDS = ("village", "random_dungeon", "symbol_dungeon", "battle")

DEFAULT_SFX_VOLUME = 0.25
BGM_VOLUME = 0.42
SFX_VOLUMES = {
    "cancel": 0.14,
}

WAV_SUFFIX = "." + "wav"
WEB_AUDIO_SUFFIXES = (WAV_SUFFIX, "-pygbag.ogg", ".ogg")
DESKTOP_AUDIO_SUFFIXES = (WAV_SUFFIX, "-pygbag.ogg", ".ogg")


def pre_init_mixer() -> None:
    pygame.mixer.pre_init(
        frequency=MIXER_FREQUENCY,
        size=MIXER_SIZE,
        channels=MIXER_CHANNELS,
        buffer=MIXER_BUFFER,
    )


class AudioManager:
    def __init__(self) -> None:
        self.enabled = False
        self.current_bgm: str | None = None
        self.music_paused = False
        self.sounds: dict[str, pygame.mixer.Sound] = {}
        try:
            if pygame.mixer.get_init() is None:
                pygame.mixer.init(
                    frequency=MIXER_FREQUENCY,
                    size=MIXER_SIZE,
                    channels=MIXER_CHANNELS,
                    buffer=MIXER_BUFFER,
                )
            self.enabled = True
            self.load_sounds()
            pygame.mixer.music.set_volume(BGM_VOLUME)
        except pygame.error:
            self.enabled = False

    def load_sounds(self) -> None:
        for sound_id in SFX_IDS:
            sound = load_sound(sound_id)
            if sound is None:
                continue
            sound.set_volume(SFX_VOLUMES.get(sound_id, DEFAULT_SFX_VOLUME))
            self.sounds[sound_id] = sound

    def play_sfx(self, sound_id: str) -> None:
        if not self.enabled:
            return
        sound = self.sounds.get(sound_id)
        if sound is not None:
            sound.play()

    def play_bgm(self, bgm_id: str) -> None:
        if not self.enabled or self.current_bgm == bgm_id:
            return
        for path in audio_paths(BGM_DIR, bgm_id):
            try:
                pygame.mixer.music.load(str(path))
                pygame.mixer.music.play(-1)
                self.current_bgm = bgm_id
                self.music_paused = False
                return
            except pygame.error:
                continue
        self.current_bgm = None

    def play_map_bgm(self, map_id: str) -> None:
        if map_id in BGM_IDS:
            self.play_bgm(map_id)

    def pause_music(self) -> None:
        if not self.enabled:
            return
        pygame.mixer.music.pause()
        pygame.mixer.stop()
        self.music_paused = True

    def resume_music(self) -> None:
        if not self.enabled or not self.music_paused:
            return
        pygame.mixer.music.unpause()
        self.music_paused = False

    def stop_all(self) -> None:
        if not self.enabled:
            return
        pygame.mixer.music.stop()
        pygame.mixer.stop()
        self.current_bgm = None
        self.music_paused = False


def load_sound(sound_id: str) -> pygame.mixer.Sound | None:
    for path in audio_paths(SFX_DIR, sound_id):
        try:
            return pygame.mixer.Sound(str(path))
        except pygame.error:
            continue
    return None


def audio_paths(directory: Path, stem: str) -> list[Path]:
    paths = []
    for suffix in audio_suffixes():
        path = directory / f"{stem}{suffix}"
        if path.exists():
            paths.append(path)
    return paths


def audio_suffixes() -> tuple[str, ...]:
    if sys.platform == "emscripten":
        return WEB_AUDIO_SUFFIXES
    return DESKTOP_AUDIO_SUFFIXES
