from __future__ import annotations

import sys
from pathlib import Path

import pygame

AUDIO_DIR = Path(__file__).resolve().parent.parent / "assets" / "audio"
SFX_DIR = AUDIO_DIR / "sfx"
BGM_DIR = AUDIO_DIR / "bgm"

SFX_IDS = (
    "cursor",
    "confirm",
    "cancel",
    "talk",
    "attack",
    "damage",
    "heal",
    "battle_start",
    "victory",
)

BGM_IDS = ("village", "random_dungeon", "symbol_dungeon", "battle")

DEFAULT_SFX_VOLUME = 0.25
SFX_VOLUMES = {
    "cancel": 0.14,
}

WAV_SUFFIX = "." + "wav"
WEB_AUDIO_SUFFIXES = ("-pygbag.ogg", ".ogg", WAV_SUFFIX)
DESKTOP_AUDIO_SUFFIXES = (WAV_SUFFIX, "-pygbag.ogg", ".ogg")


class AudioManager:
    def __init__(self) -> None:
        self.enabled = False
        self.current_bgm: str | None = None
        self.sounds: dict[str, pygame.mixer.Sound] = {}
        try:
            if pygame.mixer.get_init() is None:
                pygame.mixer.init()
            self.enabled = True
            self.load_sounds()
            pygame.mixer.music.set_volume(0.42)
        except pygame.error:
            self.enabled = False

    def load_sounds(self) -> None:
        for sound_id in SFX_IDS:
            path = audio_path(SFX_DIR, sound_id)
            if path is None:
                continue
            sound = pygame.mixer.Sound(str(path))
            sound.set_volume(SFX_VOLUMES.get(sound_id, DEFAULT_SFX_VOLUME))
            self.sounds[sound_id] = sound

    def play_sfx(self, sound_id: str) -> None:
        if not self.enabled:
            return
        sound = self.sounds.get(sound_id)
        if sound is not None:
            sound.play()

    def play_bgm(self, bgm_id: str) -> None:
        if not self.enabled or self.current_bgm == bgm_id:
            return
        path = audio_path(BGM_DIR, bgm_id)
        if path is None:
            return
        try:
            pygame.mixer.music.load(str(path))
            pygame.mixer.music.play(-1)
            self.current_bgm = bgm_id
        except pygame.error:
            self.current_bgm = None

    def play_map_bgm(self, map_id: str) -> None:
        if map_id in BGM_IDS:
            self.play_bgm(map_id)

    def stop_bgm(self) -> None:
        if self.enabled:
            pygame.mixer.music.stop()
        self.current_bgm = None


def audio_path(directory: Path, stem: str) -> Path | None:
    for suffix in audio_suffixes():
        path = directory / f"{stem}{suffix}"
        if path.exists():
            return path
    return None


def audio_suffixes() -> tuple[str, ...]:
    if sys.platform == "emscripten":
        return WEB_AUDIO_SUFFIXES
    return DESKTOP_AUDIO_SUFFIXES
