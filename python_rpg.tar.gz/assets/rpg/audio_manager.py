from __future__ import annotations

import sys
from pathlib import Path

import pygame

AUDIO_DIR = Path(__file__).resolve().parent.parent / "assets" / "audio"
BGM_DIR = AUDIO_DIR / "bgm"
BGS_DIR = AUDIO_DIR / "bgs"
ME_DIR = AUDIO_DIR / "me"
SE_DIR = AUDIO_DIR / "se"

MIXER_FREQUENCY = 44100
MIXER_SIZE = -16
MIXER_CHANNELS = 2
MIXER_BUFFER = 4096

BGM_IDS = ("field", "battle", "village", "dungeon", "random_dungeon", "symbol_dungeon")
BGS_IDS = ("rain", "wind", "river", "fireplace")
ME_IDS = ("victory", "level_up", "inn", "game_over")
SE_IDS = (
    "cursor",
    "confirm",
    "cancel",
    "talk",
    "attack_prepare",
    "magic_prepare",
    "attack_hit",
    "evade",
    "damage",
    "heal",
    "battle_start",
)

MAP_BGM_IDS = {
    "village": "village",
    "random_dungeon": "random_dungeon",
    "symbol_dungeon": "symbol_dungeon",
}

DEFAULT_SE_VOLUME = 0.25
BGM_VOLUME = 0.42
BGS_VOLUME = 0.35
ME_VOLUME = 0.4
SE_VOLUMES = {
    "cancel": 0.14,
}

WAV_SUFFIX = "." + "wav"
WEB_AUDIO_SUFFIXES = (WAV_SUFFIX, "-pygbag.ogg", ".ogg")
DESKTOP_AUDIO_SUFFIXES = (WAV_SUFFIX, "-pygbag.ogg", ".ogg")

BGS_CHANNEL_INDEX = 0
ME_CHANNEL_INDEX = 1
RESERVED_CHANNELS = 2


def pre_init_mixer() -> None:
    pygame.mixer.pre_init(
        frequency=MIXER_FREQUENCY,
        size=MIXER_SIZE,
        channels=MIXER_CHANNELS,
        buffer=MIXER_BUFFER,
    )


class AudioManager:
    def __init__(self) -> None:
        self.enabled = False
        self.current_bgm: str | None = None
        self.current_bgs: str | None = None
        self.music_paused = False
        self.se_sounds: dict[str, pygame.mixer.Sound] = {}
        self.me_sounds: dict[str, pygame.mixer.Sound] = {}
        self.bgs_sounds: dict[str, pygame.mixer.Sound] = {}
        self.warned_missing: set[tuple[str, str]] = set()
        self.bgs_channel: pygame.mixer.Channel | None = None
        self.me_channel: pygame.mixer.Channel | None = None
        try:
            if pygame.mixer.get_init() is None:
                pygame.mixer.init(
                    frequency=MIXER_FREQUENCY,
                    size=MIXER_SIZE,
                    channels=MIXER_CHANNELS,
                    buffer=MIXER_BUFFER,
                )
            pygame.mixer.set_reserved(RESERVED_CHANNELS)
            self.bgs_channel = pygame.mixer.Channel(BGS_CHANNEL_INDEX)
            self.me_channel = pygame.mixer.Channel(ME_CHANNEL_INDEX)
            self.enabled = True
            self.load_se_sounds()
            pygame.mixer.music.set_volume(BGM_VOLUME)
        except pygame.error:
            self.enabled = False

    def load_se_sounds(self) -> None:
        for sound_id in SE_IDS:
            sound = self.load_sound(SE_DIR, sound_id, "SE", warn_missing=False)
            if sound is None:
                continue
            sound.set_volume(SE_VOLUMES.get(sound_id, DEFAULT_SE_VOLUME))
            self.se_sounds[sound_id] = sound

    def play_bgm(self, bgm_id: str) -> None:
        if not self.enabled or self.current_bgm == bgm_id:
            return
        path = self.find_audio_path(BGM_DIR, bgm_id, "BGM")
        if path is None:
            self.current_bgm = None
            return
        try:
            pygame.mixer.music.load(str(path))
            pygame.mixer.music.set_volume(BGM_VOLUME)
            pygame.mixer.music.play(-1)
            self.current_bgm = bgm_id
            self.music_paused = False
        except pygame.error as exc:
            self.warn_audio("BGM", bgm_id, f"load failed: {exc}")
            self.current_bgm = None

    def stop_bgm(self) -> None:
        if not self.enabled:
            return
        pygame.mixer.music.stop()
        self.current_bgm = None

    def play_map_bgm(self, map_id: str) -> None:
        self.play_bgm(MAP_BGM_IDS.get(map_id, map_id))

    def play_bgs(self, bgs_id: str) -> None:
        if not self.enabled or self.current_bgs == bgs_id:
            return
        sound = self.bgs_sounds.get(bgs_id)
        if sound is None:
            sound = self.load_sound(BGS_DIR, bgs_id, "BGS")
            if sound is None:
                self.current_bgs = None
                return
            sound.set_volume(BGS_VOLUME)
            self.bgs_sounds[bgs_id] = sound
        if self.bgs_channel is not None:
            self.bgs_channel.play(sound, loops=-1)
            self.current_bgs = bgs_id

    def stop_bgs(self) -> None:
        if not self.enabled:
            return
        if self.bgs_channel is not None:
            self.bgs_channel.stop()
        self.current_bgs = None

    def play_me(self, me_id: str) -> None:
        if not self.enabled:
            return
        sound = self.me_sounds.get(me_id)
        if sound is None:
            sound = self.load_sound(ME_DIR, me_id, "ME")
            if sound is None:
                return
            sound.set_volume(ME_VOLUME)
            self.me_sounds[me_id] = sound
        if self.me_channel is not None:
            self.me_channel.play(sound)

    def play_se(self, se_id: str) -> None:
        if not self.enabled:
            return
        sound = self.se_sounds.get(se_id)
        if sound is None:
            sound = self.load_sound(SE_DIR, se_id, "SE")
            if sound is None:
                return
            sound.set_volume(SE_VOLUMES.get(se_id, DEFAULT_SE_VOLUME))
            self.se_sounds[se_id] = sound
        sound.play()

    def play_sfx(self, sound_id: str) -> None:
        self.play_se(sound_id)

    def pause_music(self) -> None:
        if not self.enabled:
            return
        pygame.mixer.music.pause()
        pygame.mixer.pause()
        self.music_paused = True

    def resume_music(self) -> None:
        if not self.enabled or not self.music_paused:
            return
        pygame.mixer.music.unpause()
        pygame.mixer.unpause()
        self.music_paused = False

    def stop_all(self) -> None:
        if not self.enabled:
            return
        pygame.mixer.music.stop()
        pygame.mixer.stop()
        self.current_bgm = None
        self.current_bgs = None
        self.music_paused = False

    def load_sound(
        self, directory: Path, sound_id: str, category: str, warn_missing: bool = True
    ) -> pygame.mixer.Sound | None:
        path = self.find_audio_path(directory, sound_id, category, warn_missing)
        if path is None:
            return None
        try:
            return pygame.mixer.Sound(str(path))
        except pygame.error as exc:
            self.warn_audio(category, sound_id, f"load failed: {exc}")
            return None

    def find_audio_path(
        self, directory: Path, stem: str, category: str, warn_missing: bool = True
    ) -> Path | None:
        for suffix in audio_suffixes():
            path = directory / f"{stem}{suffix}"
            if path.exists():
                return path
        if warn_missing:
            self.warn_audio(category, stem, "file not found")
        return None

    def warn_audio(self, category: str, sound_id: str, detail: str) -> None:
        key = (category, sound_id)
        if key in self.warned_missing:
            return
        self.warned_missing.add(key)
        print(f"Audio warning: {category} '{sound_id}' skipped ({detail}).")


def audio_suffixes() -> tuple[str, ...]:
    if sys.platform == "emscripten":
        return WEB_AUDIO_SUFFIXES
    return DESKTOP_AUDIO_SUFFIXES
