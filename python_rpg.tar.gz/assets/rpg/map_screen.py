from __future__ import annotations

import pygame

from rpg.character_sprites import HERO, VILLAGER, animation_frame, direction_from_vector, enemy_sprite_id
from rpg.constants import (
    COLOR_ACCENT,
    COLOR_BLACK,
    COLOR_BG,
    COLOR_GOLD,
    COLOR_HP,
    COLOR_MP,
    COLOR_MUTED,
    COLOR_PANEL,
    COLOR_PANEL_ALT,
    COLOR_TEXT,
    PLAYER_MOVE_DURATION_MS,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    TILE_SIZE,
    VIEWPORT_HEIGHT,
    VIEWPORT_WIDTH,
)
from rpg.models import EnemySpot
from rpg.screen_utils import draw_bar, draw_text


class MapScreen:
    def __init__(self, game: object) -> None:
        self.game = game

    def draw(self) -> None:
        game = self.game
        game.screen.fill(COLOR_BG)
        start_x = max(0, int(game.camera_x) // TILE_SIZE)
        end_x = min(game.current_map.width, (int(game.camera_x) + VIEWPORT_WIDTH) // TILE_SIZE + 2)
        start_y = max(0, int(game.camera_y) // TILE_SIZE)
        end_y = min(game.current_map.height, (int(game.camera_y) + VIEWPORT_HEIGHT) // TILE_SIZE + 2)

        for tile_y in range(start_y, end_y):
            for tile_x in range(start_x, end_x):
                self.draw_floor_tile(tile_x, tile_y)

        for tile_y in range(start_y, end_y):
            for tile_x in range(start_x, end_x):
                self.draw_object_tile(tile_x, tile_y)

        for npc in game.current_map.npcs:
            self.draw_sprite_at(npc.x, npc.y, VILLAGER, "down", 1)
        for enemy in game.current_map.enemies:
            if not enemy.defeated:
                self.draw_enemy_sprite(enemy)

        self.draw_player_sprite()
        if game.dialog_pages:
            self.draw_dialog()
        self.draw_hud()

    def draw_floor_tile(self, tile_x: int, tile_y: int) -> None:
        game = self.game
        tile = game.current_map.floor_tile_at(tile_x, tile_y)
        screen_x = int(tile_x * TILE_SIZE - game.camera_x)
        screen_y = int(tile_y * TILE_SIZE - game.camera_y)
        game.screen.blit(game.tiles.get(tile), (screen_x, screen_y))

    def draw_object_tile(self, tile_x: int, tile_y: int) -> None:
        game = self.game
        tile = game.current_map.object_tile_at(tile_x, tile_y)
        if tile is None:
            return
        screen_x = int(tile_x * TILE_SIZE - game.camera_x)
        screen_y = int(tile_y * TILE_SIZE - game.camera_y)
        game.screen.blit(game.tiles.get(tile), (screen_x, screen_y))

    def draw_hud(self) -> None:
        game = self.game
        hud_rect = pygame.Rect(0, VIEWPORT_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT - VIEWPORT_HEIGHT)
        pygame.draw.rect(game.screen, COLOR_PANEL, hud_rect)
        pygame.draw.line(game.screen, COLOR_PANEL_ALT, (0, VIEWPORT_HEIGHT), (SCREEN_WIDTH, VIEWPORT_HEIGHT), 3)
        draw_text(game.screen, game.current_map.name, 24, VIEWPORT_HEIGHT + 14, game.big_font, COLOR_TEXT)
        draw_text(game.screen, game.map_message, 24, VIEWPORT_HEIGHT + 55, game.font, COLOR_MUTED)
        draw_text(game.screen, "M: メニュー  Enter/Space: 話す", 24, VIEWPORT_HEIGHT + 84, game.small_font, COLOR_MUTED)

        x = 340
        for member in game.party:
            draw_text(game.screen, member.name, x, VIEWPORT_HEIGHT + 18, game.font, COLOR_TEXT)
            draw_bar(game.screen, x, VIEWPORT_HEIGHT + 46, 132, 10, member.hp, member.max_hp, COLOR_HP)
            draw_bar(game.screen, x, VIEWPORT_HEIGHT + 64, 132, 8, member.mp, member.max_mp, COLOR_MP)
            draw_text(game.screen, f"HP {member.hp}/{member.max_hp}", x + 142, VIEWPORT_HEIGHT + 39, game.small_font, COLOR_TEXT)
            draw_text(game.screen, f"MP {member.mp}/{member.max_mp}", x + 142, VIEWPORT_HEIGHT + 59, game.small_font, COLOR_MUTED)
            x += 232

    def draw_dialog(self) -> None:
        game = self.game
        panel = pygame.Rect(48, VIEWPORT_HEIGHT - 112, SCREEN_WIDTH - 96, 94)
        pygame.draw.rect(game.screen, COLOR_BLACK, panel.move(4, 5), border_radius=8)
        pygame.draw.rect(game.screen, COLOR_PANEL, panel, border_radius=8)
        pygame.draw.rect(game.screen, COLOR_ACCENT, panel, 2, border_radius=8)
        speaker = game.dialog_speaker or "村人"
        message = game.dialog_pages[game.dialog_index]
        draw_text(game.screen, speaker, panel.x + 20, panel.y + 13, game.font, COLOR_GOLD)
        draw_text(game.screen, message, panel.x + 20, panel.y + 46, game.font, COLOR_TEXT)

    def draw_player_sprite(self) -> None:
        game = self.game
        direction = direction_from_vector(game.facing_dx, game.facing_dy)
        frame = animation_frame(game.player_moving, game.player_move_elapsed_ms, PLAYER_MOVE_DURATION_MS)
        self.draw_sprite_at(game.player_visual_x, game.player_visual_y, HERO, direction, frame)

    def draw_enemy_sprite(self, enemy: EnemySpot) -> None:
        direction = direction_from_vector(enemy.facing_dx, enemy.facing_dy)
        frame = animation_frame(enemy.moving, enemy.move_elapsed_ms, enemy.move_duration_ms)
        self.draw_sprite_at(enemy.visual_x, enemy.visual_y, enemy_sprite_id(enemy.kind), direction, frame)

    def draw_sprite_at(self, tile_x: float, tile_y: float, sprite_id: str, direction: str, frame: int) -> None:
        game = self.game
        screen_x = int(tile_x * TILE_SIZE - game.camera_x)
        screen_y = int(tile_y * TILE_SIZE - game.camera_y)
        if screen_x < -TILE_SIZE or screen_y < -TILE_SIZE or screen_x > VIEWPORT_WIDTH or screen_y > VIEWPORT_HEIGHT:
            return
        sprite = game.sprites.get(sprite_id, direction, frame)
        game.screen.blit(sprite, (screen_x, screen_y))
