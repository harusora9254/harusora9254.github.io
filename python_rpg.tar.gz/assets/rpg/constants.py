from __future__ import annotations

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TILE_SIZE = 32
HUD_HEIGHT = 120
VIEWPORT_WIDTH = SCREEN_WIDTH
VIEWPORT_HEIGHT = SCREEN_HEIGHT - HUD_HEIGHT
FPS = 60
PLAYER_MOVE_DURATION_MS = 160
SYMBOL_MOVE_DURATION_MS = 260
SYMBOL_MOVE_WAIT_MIN_MS = 450
SYMBOL_MOVE_WAIT_MAX_MS = 1100

STATE_MAP = "map"
STATE_MENU = "menu"
STATE_BATTLE = "battle"

COLOR_BG = (22, 24, 28)
COLOR_PANEL = (31, 34, 42)
COLOR_PANEL_ALT = (43, 47, 57)
COLOR_TEXT = (237, 239, 231)
COLOR_MUTED = (168, 174, 168)
COLOR_ACCENT = (91, 168, 224)
COLOR_GOLD = (224, 182, 91)
COLOR_HP = (88, 202, 114)
COLOR_MP = (92, 142, 223)
COLOR_DANGER = (220, 85, 85)
COLOR_BLACK = (12, 13, 16)

BLOCKED_TILES = {"wall", "water", "tree", "dungeon_wall"}
L2_OBJECT_TILES = {"tree", "rock"}

DEFAULT_ELEMENT_RESISTANCES = {
    "fire": 1.0,
    "ice": 1.0,
    "thunder": 1.0,
    "water": 1.0,
    "earth": 1.0,
    "wind": 1.0,
    "light": 1.0,
    "dark": 1.0,
}

DEFAULT_STATE_RESISTANCES = {
    "poison": 1.0,
    "sleep": 1.0,
    "paralysis": 1.0,
    "silence": 1.0,
    "confusion": 1.0,
    "blind": 1.0,
}

ENEMY_DATA = {
    "スライム": {
        "max_hp": 35,
        "max_mp": 0,
        "attack": 8,
        "defense": 4,
        "magic_attack": 6,
        "magic_defense": 4,
        "speed": 6,
        "luck": 8,
        "hit_rate": 0.95,
        "evasion_rate": 0.03,
        "critical_rate": 0.02,
        "critical_evasion_rate": 0.0,
        "target_rate": 1.0,
        "element_resistances": {
            **DEFAULT_ELEMENT_RESISTANCES,
            "fire": 1.5,
            "ice": 0.5,
        },
        "state_resistances": DEFAULT_STATE_RESISTANCES,
        "exp": 5,
        "exp_reward": 5,
        "gold_reward": 5,
        "drop_items": [
            {"item_id": "slime_jelly", "drop_rate": 0.2},
            {"item_id": "potion", "drop_rate": 0.05},
        ],
        "skills": [],
    },
    "ゴブリン": {
        "max_hp": 55,
        "max_mp": 0,
        "attack": 12,
        "defense": 6,
        "magic_attack": 8,
        "magic_defense": 5,
        "speed": 8,
        "luck": 10,
        "hit_rate": 0.95,
        "evasion_rate": 0.05,
        "critical_rate": 0.05,
        "critical_evasion_rate": 0.0,
        "target_rate": 1.0,
        "element_resistances": DEFAULT_ELEMENT_RESISTANCES,
        "state_resistances": {
            **DEFAULT_STATE_RESISTANCES,
            "confusion": 1.5,
        },
        "exp": 10,
        "exp_reward": 10,
        "gold_reward": 8,
        "drop_items": [
            {"item_id": "potion", "drop_rate": 0.1},
        ],
        "skills": [],
    },
    "コウモリ": {
        "max_hp": 40,
        "max_mp": 0,
        "attack": 10,
        "defense": 3,
        "magic_attack": 10,
        "magic_defense": 6,
        "speed": 14,
        "luck": 12,
        "hit_rate": 0.95,
        "evasion_rate": 0.1,
        "critical_rate": 0.04,
        "critical_evasion_rate": 0.0,
        "target_rate": 1.0,
        "element_resistances": {
            **DEFAULT_ELEMENT_RESISTANCES,
            "wind": 0.5,
            "light": 1.5,
        },
        "state_resistances": {
            **DEFAULT_STATE_RESISTANCES,
            "blind": 0.5,
        },
        "exp": 8,
        "exp_reward": 8,
        "gold_reward": 6,
        "drop_items": [
            {"item_id": "bat_wing", "drop_rate": 0.15},
        ],
        "skills": [],
    },
}
