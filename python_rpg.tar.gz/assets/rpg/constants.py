from __future__ import annotations

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TILE_SIZE = 32
HUD_HEIGHT = 120
VIEWPORT_WIDTH = SCREEN_WIDTH
VIEWPORT_HEIGHT = SCREEN_HEIGHT - HUD_HEIGHT
FPS = 60
PLAYER_MOVE_DURATION_MS = 160
SYMBOL_MOVE_DURATION_MS = 260
SYMBOL_MOVE_WAIT_MIN_MS = 450
SYMBOL_MOVE_WAIT_MAX_MS = 1100

STATE_MAP = "map"
STATE_MENU = "menu"
STATE_BATTLE = "battle"

COLOR_BG = (22, 24, 28)
COLOR_PANEL = (31, 34, 42)
COLOR_PANEL_ALT = (43, 47, 57)
COLOR_TEXT = (237, 239, 231)
COLOR_MUTED = (168, 174, 168)
COLOR_ACCENT = (91, 168, 224)
COLOR_GOLD = (224, 182, 91)
COLOR_HP = (88, 202, 114)
COLOR_MP = (92, 142, 223)
COLOR_DANGER = (220, 85, 85)
COLOR_BLACK = (12, 13, 16)

BLOCKED_TILES = {"wall", "water", "tree", "dungeon_wall"}
L2_OBJECT_TILES = {"tree", "rock"}

ENEMY_DATA = {
    "スライム": {
        "max_hp": 35,
        "attack": 8,
        "defense": 4,
        "speed": 6,
        "exp": 5,
    },
    "ゴブリン": {
        "max_hp": 55,
        "attack": 12,
        "defense": 6,
        "speed": 8,
        "exp": 10,
    },
    "コウモリ": {
        "max_hp": 40,
        "attack": 10,
        "defense": 3,
        "speed": 14,
        "exp": 8,
    },
}
