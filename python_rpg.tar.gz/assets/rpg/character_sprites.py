from __future__ import annotations

import random
from pathlib import Path

import pygame

SPRITE_SIZE = 32

DIR_DOWN = "down"
DIR_LEFT = "left"
DIR_RIGHT = "right"
DIR_UP = "up"

HERO = "hero"
VILLAGER = "villager"
WEAK_ENEMY = "weak_enemy"
STRONG_ENEMY = "strong_enemy"

ASSET_DIR = Path(__file__).resolve().parent.parent / "assets" / "images" / "characters"
DIRECTIONS = [DIR_DOWN, DIR_LEFT, DIR_RIGHT, DIR_UP]
SPRITE_FILES = {
    HERO: "hero.png",
    VILLAGER: "villager.png",
    WEAK_ENEMY: "enemy_weak.png",
    STRONG_ENEMY: "enemy_strong.png",
}


class SpriteFactory:
    def __init__(self, asset_dir: Path | None = None) -> None:
        self.asset_dir = asset_dir or ASSET_DIR
        self.sheets = self.load_sheets()
        self.cache: dict[tuple[str, str, int], pygame.Surface] = {}

    def get(self, sprite_id: str, direction: str, frame: int) -> pygame.Surface:
        key = (sprite_id, direction, frame % 4)
        if key not in self.cache:
            self.cache[key] = self.slice_frame(sprite_id, direction, frame % 4)
        return self.cache[key]

    def load_sheets(self) -> dict[str, pygame.Surface]:
        sheets = {}
        missing_files = []
        for sprite_id, filename in SPRITE_FILES.items():
            path = self.asset_dir / filename
            if not path.exists():
                missing_files.append(str(path))
                continue
            sheets[sprite_id] = pygame.image.load(str(path)).convert_alpha()

        if missing_files:
            joined_files = "\n".join(missing_files)
            raise FileNotFoundError(
                "Character sprite image files are missing. "
                "Run: cd python_rpg && venv/bin/python tools/generate_character_sprites.py\n"
                f"{joined_files}"
            )
        return sheets

    def slice_frame(self, sprite_id: str, direction: str, frame: int) -> pygame.Surface:
        sheet = self.sheets[sprite_id]
        row = DIRECTIONS.index(direction)
        rect = pygame.Rect(frame * SPRITE_SIZE, row * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)
        return sheet.subsurface(rect).copy()


def create_generated_frame(sprite_id: str, direction: str, frame: int) -> pygame.Surface:
    surface = pygame.Surface((SPRITE_SIZE, SPRITE_SIZE), pygame.SRCALPHA)
    if sprite_id == HERO:
        draw_hero(surface, direction, frame)
    elif sprite_id == VILLAGER:
        draw_villager(surface, direction, frame)
    elif sprite_id == STRONG_ENEMY:
        draw_strong_enemy(surface, direction, frame)
    else:
        draw_weak_enemy(surface, direction, frame)
    return surface


def create_sprite_sheet(sprite_id: str) -> pygame.Surface:
    sheet = pygame.Surface((SPRITE_SIZE * 4, SPRITE_SIZE * 4), pygame.SRCALPHA)
    for row, direction in enumerate(DIRECTIONS):
        for frame in range(4):
            frame_surface = create_generated_frame(sprite_id, direction, frame)
            sheet.blit(frame_surface, (frame * SPRITE_SIZE, row * SPRITE_SIZE))
    return sheet


def save_sprite_sheets(asset_dir: Path | None = None) -> list[Path]:
    target_dir = asset_dir or ASSET_DIR
    target_dir.mkdir(parents=True, exist_ok=True)
    written_paths = []
    for sprite_id, filename in SPRITE_FILES.items():
        path = target_dir / filename
        pygame.image.save(create_sprite_sheet(sprite_id), str(path))
        written_paths.append(path)
    return written_paths


def create_preview_sheet(asset_dir: Path | None = None) -> pygame.Surface:
    target_dir = asset_dir or ASSET_DIR
    preview = pygame.Surface((SPRITE_SIZE * 4, SPRITE_SIZE * 4 * len(SPRITE_FILES)), pygame.SRCALPHA)
    for index, sprite_id in enumerate(SPRITE_FILES):
        sheet_path = target_dir / SPRITE_FILES[sprite_id]
        sheet = pygame.image.load(str(sheet_path))
        preview.blit(sheet, (0, index * SPRITE_SIZE * 4))
    return preview


def direction_from_vector(dx: int, dy: int) -> str:
    if dy < 0:
        return DIR_UP
    if dx < 0:
        return DIR_LEFT
    if dx > 0:
        return DIR_RIGHT
    return DIR_DOWN


def animation_frame(moving: bool, elapsed_ms: int, duration_ms: int) -> int:
    if not moving:
        return 1
    progress = 0 if duration_ms <= 0 else min(0.999, elapsed_ms / duration_ms)
    return int(progress * 4)


def enemy_sprite_id(kind: str) -> str:
    if kind == "ゴブリン":
        return STRONG_ENEMY
    return WEAK_ENEMY


def draw_shadow(surface: pygame.Surface, x: int, y: int, width: int, height: int) -> None:
    pygame.draw.ellipse(surface, (0, 0, 0, 95), (x, y, width, height))


def draw_hero(surface: pygame.Surface, direction: str, frame: int) -> None:
    bob = 1 if frame in (1, 3) else 0
    step = [-2, 0, 2, 0][frame]
    draw_shadow(surface, 7, 26, 18, 5)

    cape_blue = (18, 54, 154)
    armor_blue = (30, 86, 202)
    armor_dark = (13, 38, 105)
    gold = (226, 172, 58)
    skin = (238, 178, 108)
    hair = (20, 87, 223)
    hair_hi = (81, 157, 255)
    outline = (9, 15, 32)

    if direction == DIR_UP:
        pygame.draw.polygon(surface, cape_blue, [(9, 15 + bob), (23, 15 + bob), (25, 28), (7, 28)])
        pygame.draw.line(surface, gold, (11, 17 + bob), (9, 27), 2)
        pygame.draw.line(surface, gold, (21, 17 + bob), (23, 27), 2)
        pygame.draw.ellipse(surface, outline, (8, 5 + bob, 16, 13))
        pygame.draw.ellipse(surface, hair, (9, 4 + bob, 14, 12))
        pygame.draw.rect(surface, armor_blue, (10, 15 + bob, 12, 10))
        draw_feet(surface, 12, 24, step, outline, armor_dark)
        pygame.draw.arc(surface, hair_hi, (10, 5 + bob, 12, 8), 3.5, 5.8, 2)
        return

    if direction in (DIR_LEFT, DIR_RIGHT):
        flip = -1 if direction == DIR_LEFT else 1
        cx = 16
        pygame.draw.polygon(
            surface,
            cape_blue,
            [(cx - 3 * flip, 15 + bob), (cx - 9 * flip, 22 + bob), (cx - 5 * flip, 27), (cx + 5 * flip, 24)],
        )
        pygame.draw.rect(surface, armor_blue, (11, 15 + bob, 11, 10))
        pygame.draw.line(surface, gold, (12, 18 + bob), (21, 18 + bob), 2)
        pygame.draw.ellipse(surface, outline, (8, 6 + bob, 16, 12))
        pygame.draw.ellipse(surface, skin, (10, 8 + bob, 12, 10))
        pygame.draw.polygon(surface, hair, [(8, 8 + bob), (18, 3 + bob), (24, 9 + bob), (21, 14 + bob), (10, 13 + bob)])
        pygame.draw.circle(surface, outline, (17 + 4 * flip, 12 + bob), 1)
        pygame.draw.rect(surface, outline, (13, 25, 4, 3))
        pygame.draw.rect(surface, outline, (19, 25, 4, 3))
        pygame.draw.rect(surface, armor_dark, (13 + step // 2, 22, 4, 5))
        pygame.draw.rect(surface, armor_dark, (19 - step // 2, 22, 4, 5))
        pygame.draw.line(surface, gold, (11, 16 + bob), (21, 16 + bob), 1)
        return

    pygame.draw.rect(surface, cape_blue, (9, 16 + bob, 14, 10))
    pygame.draw.rect(surface, armor_blue, (10, 15 + bob, 12, 10))
    pygame.draw.line(surface, gold, (10, 18 + bob), (22, 18 + bob), 2)
    pygame.draw.ellipse(surface, outline, (8, 5 + bob, 16, 14))
    pygame.draw.rect(surface, skin, (10, 9 + bob, 12, 9))
    pygame.draw.polygon(surface, hair, [(8, 8 + bob), (13, 3 + bob), (23, 6 + bob), (24, 12 + bob), (10, 12 + bob)])
    pygame.draw.circle(surface, outline, (13, 13 + bob), 1)
    pygame.draw.circle(surface, outline, (20, 13 + bob), 1)
    pygame.draw.line(surface, hair_hi, (12, 6 + bob), (20, 5 + bob), 2)
    draw_feet(surface, 12, 24, step, outline, armor_dark)


def draw_feet(
    surface: pygame.Surface,
    x: int,
    y: int,
    step: int,
    outline: tuple[int, int, int],
    color: tuple[int, int, int],
) -> None:
    pygame.draw.rect(surface, outline, (x - 1 + step // 2, y + 2, 5, 4))
    pygame.draw.rect(surface, outline, (x + 8 - step // 2, y + 2, 5, 4))
    pygame.draw.rect(surface, color, (x + step // 2, y, 4, 6))
    pygame.draw.rect(surface, color, (x + 9 - step // 2, y, 4, 6))


def draw_villager(surface: pygame.Surface, direction: str, frame: int) -> None:
    bob = 1 if frame in (1, 3) else 0
    step = [-1, 0, 1, 0][frame]
    draw_shadow(surface, 8, 26, 16, 5)
    outline = (3, 4, 5)
    body = (20, 22, 24)
    mid = (33, 35, 38)
    hi = (52, 54, 57)

    if direction in (DIR_LEFT, DIR_RIGHT):
        flip = -1 if direction == DIR_LEFT else 1
        pygame.draw.ellipse(surface, outline, (8, 5 + bob, 15, 14))
        pygame.draw.ellipse(surface, body, (9, 6 + bob, 13, 12))
        pygame.draw.polygon(surface, body, [(11, 17 + bob), (22, 16 + bob), (24, 25), (10, 26)])
        pygame.draw.rect(surface, mid, (12 + step // 2, 24, 4, 5))
        pygame.draw.rect(surface, mid, (18 - step // 2, 24, 4, 5))
        pygame.draw.arc(surface, hi, (9 - 2 * flip, 7 + bob, 14, 9), 0.2, 2.0, 1)
        return

    pygame.draw.ellipse(surface, outline, (8, 5 + bob, 16, 14))
    pygame.draw.ellipse(surface, body, (9, 6 + bob, 14, 12))
    pygame.draw.rect(surface, body, (10, 17 + bob, 12, 9))
    pygame.draw.rect(surface, mid, (11 + step // 2, 24, 4, 5))
    pygame.draw.rect(surface, mid, (18 - step // 2, 24, 4, 5))
    if direction == DIR_DOWN:
        pygame.draw.arc(surface, hi, (10, 7 + bob, 12, 8), 3.3, 5.8, 1)
    else:
        pygame.draw.arc(surface, hi, (10, 6 + bob, 12, 8), 0.2, 3.0, 1)


def draw_weak_enemy(surface: pygame.Surface, direction: str, frame: int) -> None:
    bob = [0, 1, 0, -1][frame]
    random.seed(frame + 13)
    draw_shadow(surface, 7, 26, 18, 5)
    for _ in range(18):
        x = random.randint(6, 21)
        y = random.randint(8, 24) + bob
        radius = random.randint(2, 5)
        shade = random.randint(35, 82)
        pygame.draw.circle(surface, (shade, shade, shade, 150), (x, y), radius)
    pygame.draw.ellipse(surface, (17, 18, 19), (7, 8 + bob, 18, 19))
    pygame.draw.ellipse(surface, (34, 35, 37), (9, 9 + bob, 14, 16))

    if direction == DIR_UP:
        return
    if direction == DIR_LEFT:
        pygame.draw.circle(surface, (230, 236, 240), (11, 16 + bob), 2)
    elif direction == DIR_RIGHT:
        pygame.draw.circle(surface, (230, 236, 240), (21, 16 + bob), 2)
    else:
        pygame.draw.circle(surface, (230, 236, 240), (13, 16 + bob), 2)
        pygame.draw.circle(surface, (230, 236, 240), (20, 16 + bob), 2)


def draw_strong_enemy(surface: pygame.Surface, direction: str, frame: int) -> None:
    bob = 1 if frame in (1, 3) else 0
    step = [-1, 0, 1, 0][frame]
    draw_shadow(surface, 5, 26, 22, 6)
    outline = (6, 7, 8)
    body = (28, 30, 31)
    mid = (48, 50, 52)
    eye = (235, 26, 24)

    if direction == DIR_UP:
        pygame.draw.polygon(surface, outline, [(9, 9 + bob), (5, 3 + bob), (12, 8 + bob)])
        pygame.draw.polygon(surface, outline, [(23, 9 + bob), (27, 3 + bob), (20, 8 + bob)])
        pygame.draw.ellipse(surface, body, (7, 8 + bob, 18, 16))
        pygame.draw.rect(surface, body, (9, 18 + bob, 14, 9))
        pygame.draw.rect(surface, mid, (10 + step, 25, 5, 4))
        pygame.draw.rect(surface, mid, (18 - step, 25, 5, 4))
        return

    if direction in (DIR_LEFT, DIR_RIGHT):
        flip = -1 if direction == DIR_LEFT else 1
        pygame.draw.polygon(surface, outline, [(16, 10 + bob), (8, 5 + bob), (12, 14 + bob)])
        pygame.draw.polygon(surface, outline, [(19, 8 + bob), (25, 3 + bob), (22, 13 + bob)])
        pygame.draw.ellipse(surface, body, (8, 7 + bob, 18, 15))
        pygame.draw.polygon(surface, body, [(10, 18 + bob), (23, 17 + bob), (25, 27), (8, 27)])
        pygame.draw.circle(surface, eye, (17 + 4 * flip, 14 + bob), 2)
        pygame.draw.rect(surface, mid, (11 + step, 25, 5, 4))
        pygame.draw.rect(surface, mid, (19 - step, 25, 5, 4))
        pygame.draw.circle(surface, (95, 98, 100), (14 - 2 * flip, 19 + bob), 2)
        return

    pygame.draw.polygon(surface, outline, [(9, 10 + bob), (5, 3 + bob), (13, 8 + bob)])
    pygame.draw.polygon(surface, outline, [(23, 10 + bob), (27, 3 + bob), (19, 8 + bob)])
    pygame.draw.ellipse(surface, body, (7, 7 + bob, 18, 16))
    pygame.draw.polygon(surface, body, [(8, 18 + bob), (24, 18 + bob), (25, 27), (7, 27)])
    pygame.draw.circle(surface, eye, (13, 14 + bob), 2)
    pygame.draw.circle(surface, eye, (20, 14 + bob), 2)
    pygame.draw.circle(surface, (95, 98, 100), (12, 20 + bob), 2)
    pygame.draw.circle(surface, (95, 98, 100), (21, 20 + bob), 2)
    pygame.draw.rect(surface, mid, (10 + step, 25, 5, 4))
    pygame.draw.rect(surface, mid, (18 - step, 25, 5, 4))
