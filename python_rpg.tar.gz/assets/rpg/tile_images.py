from __future__ import annotations

from pathlib import Path

import pygame

from rpg.constants import TILE_SIZE

TILE_ASSET_DIR = Path(__file__).resolve().parent.parent / "assets" / "images" / "tiles"

L1_TILE_FILES = {
    "grass": "l1_grass.png",
    "path": "l1_path.png",
    "water": "l1_water.png",
    "wall": "l1_wall.png",
    "dungeon_floor": "l1_dungeon_floor.png",
    "dungeon_wall": "l1_dungeon_wall.png",
    "exit": "l1_exit.png",
}

L2_TILE_FILES = {
    "tree": "l2_tree.png",
    "rock": "l2_rock.png",
}

TILE_FILES = {**L1_TILE_FILES, **L2_TILE_FILES}


class TileSet:
    def __init__(self, asset_dir: Path | None = None) -> None:
        self.asset_dir = asset_dir or TILE_ASSET_DIR
        self.images = self.load_images()

    def get(self, tile_id: str) -> pygame.Surface:
        return self.images[tile_id]

    def load_images(self) -> dict[str, pygame.Surface]:
        images = {}
        missing_files = []
        for tile_id, filename in TILE_FILES.items():
            path = self.asset_dir / filename
            if not path.exists():
                missing_files.append(str(path))
                continue
            images[tile_id] = pygame.image.load(str(path)).convert_alpha()
        if missing_files:
            joined_files = "\n".join(missing_files)
            raise FileNotFoundError(
                "Tile image files are missing. "
                "Run: cd python_rpg && venv/bin/python tools/generate_tile_images.py\n"
                f"{joined_files}"
            )
        return images


def save_tile_images(asset_dir: Path | None = None) -> list[Path]:
    target_dir = asset_dir or TILE_ASSET_DIR
    target_dir.mkdir(parents=True, exist_ok=True)
    written_paths = []
    for tile_id, filename in TILE_FILES.items():
        path = target_dir / filename
        pygame.image.save(create_tile_image(tile_id), str(path))
        written_paths.append(path)
    return written_paths


def create_tile_image(tile_id: str) -> pygame.Surface:
    surface = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
    if tile_id == "grass":
        fill_checker(surface, (82, 148, 82), (72, 134, 74))
        scatter_pixels(surface, (112, 178, 96), 24)
    elif tile_id == "path":
        fill_checker(surface, (157, 132, 83), (145, 121, 74))
        scatter_pixels(surface, (185, 158, 100), 18)
    elif tile_id == "water":
        fill_checker(surface, (48, 103, 168), (41, 91, 151))
        for y in (9, 20):
            pygame.draw.arc(surface, (98, 165, 219), (3, y, 26, 8), 0.1, 2.8, 1)
    elif tile_id == "wall":
        draw_bricks(surface, (70, 75, 84), (50, 54, 62), (94, 101, 111))
    elif tile_id == "dungeon_floor":
        fill_checker(surface, (101, 94, 88), (89, 83, 78))
        scatter_pixels(surface, (125, 118, 108), 14)
    elif tile_id == "dungeon_wall":
        draw_bricks(surface, (48, 48, 58), (34, 34, 42), (72, 72, 86))
    elif tile_id == "exit":
        fill_checker(surface, (83, 132, 98), (72, 116, 87))
        pygame.draw.polygon(surface, (174, 222, 168), [(16, 6), (26, 20), (20, 20), (20, 27), (12, 27), (12, 20), (6, 20)])
    elif tile_id == "tree":
        draw_tree(surface)
    elif tile_id == "rock":
        draw_rock(surface)
    return surface


def fill_checker(surface: pygame.Surface, color_a: tuple[int, int, int], color_b: tuple[int, int, int]) -> None:
    surface.fill(color_a)
    for y in range(0, TILE_SIZE, 8):
        for x in range(0, TILE_SIZE, 8):
            if (x + y) // 8 % 2 == 0:
                pygame.draw.rect(surface, color_b, (x, y, 8, 8))


def scatter_pixels(surface: pygame.Surface, color: tuple[int, int, int], count: int) -> None:
    for index in range(count):
        x = (index * 11 + 5) % TILE_SIZE
        y = (index * 17 + 9) % TILE_SIZE
        surface.set_at((x, y), color)


def draw_bricks(
    surface: pygame.Surface,
    base: tuple[int, int, int],
    mortar: tuple[int, int, int],
    highlight: tuple[int, int, int],
) -> None:
    surface.fill(base)
    for y in range(0, TILE_SIZE, 8):
        pygame.draw.line(surface, mortar, (0, y), (TILE_SIZE, y), 1)
        offset = 8 if (y // 8) % 2 else 0
        for x in range(-offset, TILE_SIZE, 16):
            pygame.draw.line(surface, mortar, (x, y), (x, y + 8), 1)
    pygame.draw.line(surface, highlight, (0, 0), (TILE_SIZE, 0), 1)


def draw_tree(surface: pygame.Surface) -> None:
    pygame.draw.ellipse(surface, (0, 0, 0, 75), (8, 25, 17, 5))
    pygame.draw.rect(surface, (93, 65, 38), (14, 17, 5, 10))
    pygame.draw.circle(surface, (30, 95, 47), (12, 13), 8)
    pygame.draw.circle(surface, (38, 116, 55), (20, 13), 8)
    pygame.draw.circle(surface, (24, 82, 42), (16, 8), 8)
    pygame.draw.circle(surface, (49, 139, 65), (17, 14), 5)


def draw_rock(surface: pygame.Surface) -> None:
    pygame.draw.ellipse(surface, (0, 0, 0, 70), (7, 25, 18, 5))
    pygame.draw.polygon(surface, (78, 82, 87), [(8, 23), (11, 13), (19, 9), (25, 16), (23, 25), (13, 27)])
    pygame.draw.polygon(surface, (105, 110, 117), [(12, 14), (19, 10), (16, 19), (9, 22)])
    pygame.draw.line(surface, (55, 58, 64), (16, 19), (23, 25), 1)
