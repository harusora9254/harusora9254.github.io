from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from rpg.constants import L2_OBJECT_TILES, SYMBOL_MOVE_DURATION_MS
from rpg.models import EnemySpot, GameMap, MapExit, NPC

MAP_DIR = Path(__file__).resolve().parent.parent / "data" / "maps"


def load_map(map_id: str) -> GameMap:
    path = MAP_DIR / f"{map_id}.json"
    with path.open("r", encoding="utf-8") as file:
        data = json.load(file)
    return build_map(data)


def build_map(data: dict[str, Any]) -> GameMap:
    width = int(data["width"])
    height = int(data["height"])
    base_tile = data["base_tile"]
    floor_tiles = [[base_tile for _ in range(width)] for _ in range(height)]
    object_tiles: list[list[str | None]] = [[None for _ in range(width)] for _ in range(height)]

    for spec in data.get("floor_tiles", []):
        apply_tile_spec(floor_tiles, width, height, spec, spec["tile"])
    for spec in data.get("object_tiles", []):
        apply_tile_spec(object_tiles, width, height, spec, spec["tile"])

    # Backward compatibility for older map JSON files that used a single tile list.
    for spec in data.get("tiles", []):
        target_layer = object_tiles if spec["tile"] in L2_OBJECT_TILES else floor_tiles
        apply_tile_spec(target_layer, width, height, spec, spec["tile"])

    start = data["start"]
    enemies = [
        build_enemy_spot(enemy)
        for enemy in data.get("enemies", [])
    ]
    npcs = [
        NPC(
            npc["id"],
            npc["name"],
            int(npc["x"]),
            int(npc["y"]),
            list(npc["dialog"]),
        )
        for npc in data.get("npcs", [])
    ]
    exits = [
        MapExit(
            int(map_exit["x"]),
            int(map_exit["y"]),
            map_exit["target"],
            int(map_exit["target_x"]),
            int(map_exit["target_y"]),
            map_exit["message"],
        )
        for map_exit in data.get("exits", [])
    ]

    game_map = GameMap(
        data["id"],
        data["name"],
        width,
        height,
        floor_tiles,
        object_tiles,
        int(start["x"]),
        int(start["y"]),
        enemies,
        npcs,
        exits,
        data.get("encounter_type", "none"),
        list(data.get("random_encounters", [])),
        float(data.get("encounter_rate", 0.0)),
    )
    validate_map(game_map)
    return game_map


def build_enemy_spot(enemy: dict[str, Any]) -> EnemySpot:
    spot = EnemySpot(
        int(enemy["x"]),
        int(enemy["y"]),
        enemy["kind"],
        move_style=enemy.get("move_style", "static"),
        move_duration_ms=int(enemy.get("move_duration_ms", SYMBOL_MOVE_DURATION_MS)),
    )
    spot.visual_x = float(spot.x)
    spot.visual_y = float(spot.y)
    spot.start_x = spot.x
    spot.start_y = spot.y
    spot.target_x = spot.x
    spot.target_y = spot.y
    return spot


def apply_tile_spec(
    tiles: list[list[str | None]],
    width: int,
    height: int,
    spec: dict[str, Any],
    tile: str | None,
) -> None:
    if "rect" in spec:
        fill_rect(tiles, width, height, spec["rect"], tile)
    for point in spec.get("points", []):
        x, y = point
        if 0 <= x < width and 0 <= y < height:
            tiles[y][x] = tile


def fill_rect(
    tiles: list[list[str | None]],
    width: int,
    height: int,
    rect: list[int],
    tile: str | None,
) -> None:
    x, y, rect_width, rect_height = rect
    for tile_y in range(y, y + rect_height):
        if tile_y < 0 or tile_y >= height:
            continue
        for tile_x in range(x, x + rect_width):
            if 0 <= tile_x < width:
                tiles[tile_y][tile_x] = tile


def validate_map(game_map: GameMap) -> None:
    if len(game_map.floor_tiles) != game_map.height:
        raise ValueError(f"{game_map.map_id}: tile row count does not match height")
    if len(game_map.object_tiles) != game_map.height:
        raise ValueError(f"{game_map.map_id}: object row count does not match height")
    for row in game_map.floor_tiles:
        if len(row) != game_map.width:
            raise ValueError(f"{game_map.map_id}: tile column count does not match width")
    for row in game_map.object_tiles:
        if len(row) != game_map.width:
            raise ValueError(f"{game_map.map_id}: object column count does not match width")
