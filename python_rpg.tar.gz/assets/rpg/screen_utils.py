from __future__ import annotations

import pygame

from rpg.constants import COLOR_BLACK, COLOR_PANEL_ALT
from rpg.fonts import GameFont


def draw_bar(
    screen: pygame.Surface,
    x: int,
    y: int,
    width: int,
    height: int,
    current: int,
    maximum: int,
    fill_color: tuple[int, int, int],
) -> None:
    pygame.draw.rect(screen, COLOR_BLACK, (x, y, width, height), border_radius=4)
    ratio = 0 if maximum <= 0 else max(0, min(1, current / maximum))
    inner_width = int(width * ratio)
    if inner_width > 0:
        pygame.draw.rect(screen, fill_color, (x, y, inner_width, height), border_radius=4)
    pygame.draw.rect(screen, COLOR_PANEL_ALT, (x, y, width, height), 1, border_radius=4)


def draw_text(
    screen: pygame.Surface,
    text: str,
    x: int,
    y: int,
    font: GameFont,
    color: tuple[int, int, int],
) -> None:
    surface = font.render(text, True, color)
    screen.blit(surface, (x, y))


def draw_text_center(
    screen: pygame.Surface,
    text: str,
    x: int,
    y: int,
    font: GameFont,
    color: tuple[int, int, int],
) -> None:
    surface = font.render(text, True, color)
    rect = surface.get_rect(center=(x, y))
    screen.blit(surface, rect)
