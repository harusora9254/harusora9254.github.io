from __future__ import annotations

from dataclasses import dataclass, field

ELEMENT_IDS = (
    "fire",
    "ice",
    "thunder",
    "water",
    "earth",
    "wind",
    "light",
    "dark",
)

STATE_IDS = (
    "poison",
    "sleep",
    "paralysis",
    "silence",
    "confusion",
    "blind",
)


def default_element_resistances() -> dict[str, float]:
    return {element_id: 1.0 for element_id in ELEMENT_IDS}


def default_state_resistances() -> dict[str, float]:
    return {state_id: 1.0 for state_id in STATE_IDS}


def normalized_resistances(
    values: dict[str, float] | None, defaults: dict[str, float]
) -> dict[str, float]:
    normalized = dict(defaults)
    if values is not None:
        normalized.update({key: float(value) for key, value in values.items()})
    return normalized


@dataclass
class Skill:
    name: str
    mp_cost: int = 0
    power: float = 1.0
    type: str = "physical"
    element: str = "none"
    target: str = "enemy"

    @classmethod
    def from_data(cls, data: Skill | dict[str, object]) -> Skill:
        if isinstance(data, Skill):
            return data
        return cls(
            str(data.get("name", "")),
            int(data.get("mp_cost", data.get("skill_cost", 0))),
            float(data.get("power", 1.0)),
            str(data.get("type", "physical")),
            str(data.get("element", "none")),
            str(data.get("target", "enemy")),
        )


@dataclass
class DropItem:
    item_id: str
    drop_rate: float

    @classmethod
    def from_data(cls, data: DropItem | dict[str, object]) -> DropItem:
        if isinstance(data, DropItem):
            return data
        return cls(str(data.get("item_id", "")), float(data.get("drop_rate", 0.0)))


@dataclass
class Battler:
    name: str
    max_hp: int
    hp: int
    max_mp: int
    mp: int
    attack: int
    defense: int
    speed: int
    skill_name: str = ""
    skill_cost: int = 0
    guarding: bool = False
    magic_attack: int | None = None
    magic_defense: int | None = None
    luck: int = 10
    hit_rate: float = 0.95
    evasion_rate: float = 0.05
    critical_rate: float = 0.05
    critical_evasion_rate: float = 0.0
    target_rate: float = 1.0
    element_resistances: dict[str, float] | None = None
    state_resistances: dict[str, float] | None = None
    skills: list[Skill | dict[str, object]] = field(default_factory=list)
    exp_reward: int = 0
    gold_reward: int = 0
    drop_items: list[DropItem | dict[str, object]] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.magic_attack is None:
            self.magic_attack = self.attack
        if self.magic_defense is None:
            self.magic_defense = self.defense

        self.element_resistances = normalized_resistances(
            self.element_resistances, default_element_resistances()
        )
        self.state_resistances = normalized_resistances(
            self.state_resistances, default_state_resistances()
        )
        self.skills = [Skill.from_data(skill) for skill in self.skills]
        if not self.skills and self.skill_name:
            self.skills.append(self.legacy_skill())
        if self.skills:
            primary_skill = self.skills[0]
            self.skill_name = primary_skill.name
            self.skill_cost = primary_skill.mp_cost
        self.drop_items = [DropItem.from_data(item) for item in self.drop_items]

    def legacy_skill(self) -> Skill:
        if self.skill_name == "ヒール":
            return Skill(self.skill_name, self.skill_cost, 1.0, "heal", "light", "ally")
        return Skill(self.skill_name, self.skill_cost, 1.8, "physical", "none", "enemy")

    @property
    def alive(self) -> bool:
        return self.hp > 0

    def primary_skill(self) -> Skill | None:
        if not self.skills:
            return None
        return self.skills[0]

    def heal(self, amount: int) -> int:
        before = self.hp
        self.hp = min(self.max_hp, self.hp + amount)
        return self.hp - before

    def restore_all(self) -> None:
        self.hp = self.max_hp
        self.mp = self.max_mp
        self.guarding = False

    def spend_mp(self, amount: int) -> bool:
        if self.mp < amount:
            return False
        self.mp -= amount
        return True


class Combatant(Battler):
    pass


class Actor(Battler):
    pass


class Enemy(Battler):
    pass


@dataclass
class EnemySpot:
    x: int
    y: int
    kind: str
    defeated: bool = False
    move_style: str = "static"
    visual_x: float = 0.0
    visual_y: float = 0.0
    start_x: int = 0
    start_y: int = 0
    target_x: int = 0
    target_y: int = 0
    move_elapsed_ms: int = 0
    move_duration_ms: int = 260
    wait_ms: int = 0
    moving: bool = False
    facing_dx: int = 0
    facing_dy: int = 1


@dataclass
class NPC:
    npc_id: str
    name: str
    x: int
    y: int
    dialog: list[str]


@dataclass
class MapExit:
    x: int
    y: int
    target: str
    target_x: int
    target_y: int
    message: str


@dataclass
class GameMap:
    map_id: str
    name: str
    width: int
    height: int
    floor_tiles: list[list[str]]
    object_tiles: list[list[str | None]]
    start_x: int
    start_y: int
    enemies: list[EnemySpot] = field(default_factory=list)
    npcs: list[NPC] = field(default_factory=list)
    exits: list[MapExit] = field(default_factory=list)
    encounter_type: str = "none"
    random_encounters: list[str] = field(default_factory=list)
    encounter_rate: float = 0.0

    def tile_at(self, x: int, y: int) -> str:
        object_tile = self.object_tile_at(x, y)
        if object_tile is not None:
            return object_tile
        return self.floor_tile_at(x, y)

    def floor_tile_at(self, x: int, y: int) -> str:
        if x < 0 or y < 0 or x >= self.width or y >= self.height:
            return "wall"
        return self.floor_tiles[y][x]

    def object_tile_at(self, x: int, y: int) -> str | None:
        if x < 0 or y < 0 or x >= self.width or y >= self.height:
            return None
        return self.object_tiles[y][x]

    def enemy_targeting(self, x: int, y: int) -> EnemySpot | None:
        for enemy in self.enemies:
            if enemy.defeated:
                continue
            if enemy.x == x and enemy.y == y:
                return enemy
            if enemy.moving and enemy.target_x == x and enemy.target_y == y:
                return enemy
        return None

    def npc_at(self, x: int, y: int) -> NPC | None:
        for npc in self.npcs:
            if npc.x == x and npc.y == y:
                return npc
        return None

    def exit_at(self, x: int, y: int) -> MapExit | None:
        for map_exit in self.exits:
            if map_exit.x == x and map_exit.y == y:
                return map_exit
        return None


@dataclass
class BattleOutcome:
    result: str
    message: str
    exp: int = 0
    gold: int = 0
