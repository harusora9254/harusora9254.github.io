from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Combatant:
    name: str
    max_hp: int
    hp: int
    max_mp: int
    mp: int
    attack: int
    defense: int
    speed: int
    skill_name: str
    skill_cost: int
    guarding: bool = False

    @property
    def alive(self) -> bool:
        return self.hp > 0

    def heal(self, amount: int) -> int:
        before = self.hp
        self.hp = min(self.max_hp, self.hp + amount)
        return self.hp - before

    def restore_all(self) -> None:
        self.hp = self.max_hp
        self.mp = self.max_mp
        self.guarding = False

    def spend_mp(self, amount: int) -> bool:
        if self.mp < amount:
            return False
        self.mp -= amount
        return True


@dataclass
class EnemySpot:
    x: int
    y: int
    kind: str
    defeated: bool = False
    move_style: str = "static"
    visual_x: float = 0.0
    visual_y: float = 0.0
    start_x: int = 0
    start_y: int = 0
    target_x: int = 0
    target_y: int = 0
    move_elapsed_ms: int = 0
    move_duration_ms: int = 260
    wait_ms: int = 0
    moving: bool = False
    facing_dx: int = 0
    facing_dy: int = 1


@dataclass
class NPC:
    npc_id: str
    name: str
    x: int
    y: int
    dialog: list[str]


@dataclass
class MapExit:
    x: int
    y: int
    target: str
    target_x: int
    target_y: int
    message: str


@dataclass
class GameMap:
    map_id: str
    name: str
    width: int
    height: int
    floor_tiles: list[list[str]]
    object_tiles: list[list[str | None]]
    start_x: int
    start_y: int
    enemies: list[EnemySpot] = field(default_factory=list)
    npcs: list[NPC] = field(default_factory=list)
    exits: list[MapExit] = field(default_factory=list)
    encounter_type: str = "none"
    random_encounters: list[str] = field(default_factory=list)
    encounter_rate: float = 0.0

    def tile_at(self, x: int, y: int) -> str:
        object_tile = self.object_tile_at(x, y)
        if object_tile is not None:
            return object_tile
        return self.floor_tile_at(x, y)

    def floor_tile_at(self, x: int, y: int) -> str:
        if x < 0 or y < 0 or x >= self.width or y >= self.height:
            return "wall"
        return self.floor_tiles[y][x]

    def object_tile_at(self, x: int, y: int) -> str | None:
        if x < 0 or y < 0 or x >= self.width or y >= self.height:
            return None
        return self.object_tiles[y][x]

    def enemy_targeting(self, x: int, y: int) -> EnemySpot | None:
        for enemy in self.enemies:
            if enemy.defeated:
                continue
            if enemy.x == x and enemy.y == y:
                return enemy
            if enemy.moving and enemy.target_x == x and enemy.target_y == y:
                return enemy
        return None

    def npc_at(self, x: int, y: int) -> NPC | None:
        for npc in self.npcs:
            if npc.x == x and npc.y == y:
                return npc
        return None

    def exit_at(self, x: int, y: int) -> MapExit | None:
        for map_exit in self.exits:
            if map_exit.x == x and map_exit.y == y:
                return map_exit
        return None


@dataclass
class BattleOutcome:
    result: str
    message: str
    exp: int = 0
    gold: int = 0
