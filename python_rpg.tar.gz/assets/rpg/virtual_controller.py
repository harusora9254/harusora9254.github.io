from __future__ import annotations

import sys

import pygame

from rpg.constants import COLOR_ACCENT, COLOR_BLACK, COLOR_PANEL, COLOR_TEXT, SCREEN_HEIGHT, SCREEN_WIDTH
from rpg.screen_utils import draw_text_center

PORTRAIT_CONTROL_HEIGHT = 540
LANDSCAPE_CONTROL_WIDTH = 270
TOUCH_MOUSE_SUPPRESS_MS = 700
FINGER_EVENTS = (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP)
MOUSE_EVENTS = (pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION, pygame.MOUSEBUTTONUP)


class VirtualController:
    def __init__(self, game: object) -> None:
        self.game = game
        self.visible = False
        self.active_direction_pointer: object | None = None
        self.active_direction: tuple[int, int] | None = None
        self.suppress_mouse_until_ms = 0

    @property
    def toggle_rect(self) -> pygame.Rect:
        return pygame.Rect(SCREEN_WIDTH - 78, 12, 64, 34)

    @property
    def toggle_hit_rect(self) -> pygame.Rect:
        return pygame.Rect(SCREEN_WIDTH - 176, 0, 176, 96)

    def mobile_mode(self) -> str | None:
        return current_mobile_mode()

    def controls_visible(self) -> bool:
        return self.visible or self.mobile_mode() is not None

    def game_rect(self) -> pygame.Rect:
        mode = self.mobile_mode()
        if mode == "portrait":
            return pygame.Rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
        if mode == "landscape":
            side_width = (self.surface_size()[0] - SCREEN_WIDTH) // 2
            return pygame.Rect(side_width, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
        return pygame.Rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)

    def dpad_rects(self) -> dict[tuple[int, int], pygame.Rect]:
        mode = self.mobile_mode()
        width, height = self.surface_size()
        if mode == "portrait":
            size = 84
            gap = 8
            control_top = SCREEN_HEIGHT
            center = centered_rect(166, control_top + (height - control_top) // 2 + 12, size)
        elif mode == "landscape":
            size = 84
            gap = 8
            side_width = max(LANDSCAPE_CONTROL_WIDTH, (width - SCREEN_WIDTH) // 2)
            center = centered_rect(side_width // 2, SCREEN_HEIGHT // 2, size)
        else:
            size = 64
            gap = 6
            center = centered_rect(98, SCREEN_HEIGHT - 104, size)
        return {
            (0, -1): center.move(0, -(size + gap)),
            (0, 1): center.move(0, size + gap),
            (-1, 0): center.move(-(size + gap), 0),
            (1, 0): center.move(size + gap, 0),
        }

    def button_rects(self) -> dict[str, pygame.Rect]:
        mode = self.mobile_mode()
        width, height = self.surface_size()
        if mode == "portrait":
            size = 92
            control_top = SCREEN_HEIGHT
            center_y = control_top + (height - control_top) // 2 + 12
            return {
                "b": centered_rect(width - 272, center_y + 34, size),
                "a": centered_rect(width - 132, center_y - 52, size),
            }
        if mode == "landscape":
            size = 90
            side_width = max(LANDSCAPE_CONTROL_WIDTH, (width - SCREEN_WIDTH) // 2)
            center_x = width - side_width // 2
            return {
                "b": centered_rect(center_x - 34, SCREEN_HEIGHT // 2 + 80, size),
                "a": centered_rect(center_x + 30, SCREEN_HEIGHT // 2 - 78, size),
            }
        size = 82
        return {
            "b": centered_rect(SCREEN_WIDTH - 162, SCREEN_HEIGHT - 50, size),
            "a": centered_rect(SCREEN_WIDTH - 68, SCREEN_HEIGHT - 96, size),
        }

    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type in FINGER_EVENTS:
            self.suppress_mouse_until_ms = pygame.time.get_ticks() + TOUCH_MOUSE_SUPPRESS_MS
        elif event.type in MOUSE_EVENTS and pygame.time.get_ticks() < self.suppress_mouse_until_ms:
            return True

        pointer = self.pointer_id(event)
        pos = self.event_pos(event)
        if pos is None:
            return False

        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
            if self.mobile_mode() is None and self.toggle_hit_rect.collidepoint(pos):
                self.visible = not self.visible
                self.release_direction(pointer)
                return True
            if not self.controls_visible() and self.is_touch_event(event):
                self.visible = True
                return True
            if not self.controls_visible():
                return False
            direction = self.direction_at(pos)
            if direction is not None:
                self.active_direction_pointer = pointer
                self.active_direction = direction
                self.game.handle_virtual_direction_press(direction)
                return True
            button = self.button_at(pos)
            if button is not None:
                self.game.handle_virtual_button(button)
                return True
            return False

        if event.type in (pygame.MOUSEMOTION, pygame.FINGERMOTION):
            if not self.controls_visible() or pointer != self.active_direction_pointer:
                return False
            direction = self.direction_at(pos)
            if direction != self.active_direction:
                if self.active_direction is not None:
                    self.game.handle_virtual_direction_release(self.active_direction)
                self.active_direction = direction
                if direction is not None:
                    self.game.handle_virtual_direction_press(direction)
            return True

        if event.type in (pygame.MOUSEBUTTONUP, pygame.FINGERUP):
            if pointer == self.active_direction_pointer:
                self.release_direction(pointer)
                return True
            return self.controls_visible() and self.is_inside_controller(pos)

        return False

    def release_direction(self, pointer: object | None) -> None:
        if pointer != self.active_direction_pointer:
            return
        if self.active_direction is not None:
            self.game.handle_virtual_direction_release(self.active_direction)
        self.active_direction_pointer = None
        self.active_direction = None

    def direction_at(self, pos: tuple[int, int]) -> tuple[int, int] | None:
        for direction, rect in self.dpad_rects().items():
            if rect.collidepoint(pos):
                return direction
        return None

    def button_at(self, pos: tuple[int, int]) -> str | None:
        for button, rect in self.button_rects().items():
            if rect.collidepoint(pos):
                return button
        return None

    def is_inside_controller(self, pos: tuple[int, int]) -> bool:
        if self.mobile_mode() is None and self.toggle_hit_rect.collidepoint(pos):
            return True
        return self.direction_at(pos) is not None or self.button_at(pos) is not None

    def is_touch_event(self, event: pygame.event.Event) -> bool:
        if event.type in FINGER_EVENTS:
            return True
        return bool(getattr(event, "touch", False))

    def pointer_id(self, event: pygame.event.Event) -> object:
        if event.type in FINGER_EVENTS:
            return ("finger", event.finger_id)
        return ("mouse", getattr(event, "button", 1))

    def event_pos(self, event: pygame.event.Event) -> tuple[int, int] | None:
        if event.type in FINGER_EVENTS:
            if 0 <= event.x <= 1 and 0 <= event.y <= 1:
                width, height = self.surface_size()
                return int(event.x * width), int(event.y * height)
            return self.map_pixel_pos(event.x, event.y)
        pos = getattr(event, "pos", None)
        if pos is None:
            return None
        return self.map_pixel_pos(pos[0], pos[1])

    def map_pixel_pos(self, x: float, y: float) -> tuple[int, int]:
        screen_width, screen_height = self.surface().get_size()
        if sys.platform == "emscripten":
            window_width, window_height = browser_window_size()
            if window_width > 0 and window_height > 0:
                return int(x * screen_width / window_width), int(y * screen_height / window_height)

        if 0 <= x <= screen_width and 0 <= y <= screen_height:
            return int(x), int(y)
        try:
            window_width, window_height = pygame.display.get_window_size()
        except pygame.error:
            window_width, window_height = screen_width, screen_height
        if window_width > 0 and window_height > 0:
            return int(x * screen_width / window_width), int(y * screen_height / window_height)
        return int(x), int(y)

    def surface(self) -> pygame.Surface:
        return getattr(self.game, "display_surface", self.game.screen)

    def surface_size(self) -> tuple[int, int]:
        return self.surface().get_size()

    def draw(self) -> None:
        if self.mobile_mode() is None:
            self.draw_toggle()
        if not self.controls_visible():
            return
        self.draw_dpad()
        self.draw_buttons()

    def draw_toggle(self) -> None:
        game = self.game
        surface = self.surface()
        color = COLOR_ACCENT if self.visible else COLOR_PANEL
        pygame.draw.rect(surface, COLOR_BLACK, self.toggle_rect.move(3, 3), border_radius=6)
        pygame.draw.rect(surface, color, self.toggle_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT, self.toggle_rect, 1, border_radius=6)
        label = "HIDE" if self.visible else "PAD"
        draw_text_center(surface, label, self.toggle_rect.centerx, self.toggle_rect.centery, game.small_font, COLOR_TEXT)

    def draw_dpad(self) -> None:
        game = self.game
        surface = self.surface()
        labels = {
            (0, -1): "^",
            (0, 1): "v",
            (-1, 0): "<",
            (1, 0): ">",
        }
        for direction, rect in self.dpad_rects().items():
            color = COLOR_ACCENT if direction == self.active_direction else COLOR_PANEL
            pygame.draw.rect(surface, COLOR_BLACK, rect.move(3, 3), border_radius=8)
            pygame.draw.rect(surface, color, rect, border_radius=8)
            pygame.draw.rect(surface, COLOR_TEXT, rect, 1, border_radius=8)
            draw_text_center(surface, labels[direction], rect.centerx, rect.centery, game.big_font, COLOR_TEXT)

    def draw_buttons(self) -> None:
        game = self.game
        surface = self.surface()
        for label, rect in self.button_rects().items():
            pygame.draw.ellipse(surface, COLOR_BLACK, rect.move(4, 4))
            pygame.draw.ellipse(surface, COLOR_PANEL, rect)
            pygame.draw.ellipse(surface, COLOR_TEXT, rect, 2)
            draw_text_center(surface, label.upper(), rect.centerx, rect.centery, game.big_font, COLOR_TEXT)


def centered_rect(center_x: int, center_y: int, size: int) -> pygame.Rect:
    return pygame.Rect(center_x - size // 2, center_y - size // 2, size, size)


def current_mobile_mode() -> str | None:
    if sys.platform != "emscripten":
        return None
    width, height = browser_window_size()
    if not is_mobile_window(width, height):
        return None
    if height >= width:
        return "portrait"
    return "landscape"


def browser_window_size() -> tuple[int, int]:
    try:
        from platform import window

        width = int(window.innerWidth)
        height = int(window.innerHeight)
        if width > 0 and height > 0:
            return width, height
    except (ImportError, AttributeError, TypeError, ValueError):
        pass
    try:
        return pygame.display.get_window_size()
    except pygame.error:
        return SCREEN_WIDTH, SCREEN_HEIGHT


def is_mobile_window(width: int, height: int) -> bool:
    try:
        from platform import window

        user_agent = str(window.navigator.userAgent).lower()
        mobile_terms = ("android", "iphone", "ipad", "ipod", "mobile")
        if any(term in user_agent for term in mobile_terms):
            return True
    except (ImportError, AttributeError, TypeError):
        pass
    return min(width, height) < 520 and max(width, height) < 1000


def display_size_for_mode(mode: str | None) -> tuple[int, int]:
    if mode == "portrait":
        return SCREEN_WIDTH, SCREEN_HEIGHT + PORTRAIT_CONTROL_HEIGHT
    if mode == "landscape":
        return SCREEN_WIDTH + LANDSCAPE_CONTROL_WIDTH * 2, SCREEN_HEIGHT
    return SCREEN_WIDTH, SCREEN_HEIGHT
