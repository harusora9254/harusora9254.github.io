from __future__ import annotations

import pygame

from rpg.character_sprites import enemy_sprite_id
from rpg.constants import COLOR_BLACK, COLOR_DANGER, COLOR_HP, COLOR_MP, COLOR_MUTED, COLOR_PANEL, COLOR_PANEL_ALT, COLOR_TEXT, STATE_BATTLE
from rpg.screen_utils import draw_bar, draw_text, draw_text_center


class BattleScreen:
    def __init__(self, game: object) -> None:
        self.game = game

    def draw(self) -> None:
        game = self.game
        game.screen.fill((26, 28, 34))
        draw_text(game.screen, "戦闘", 38, 28, game.big_font, COLOR_TEXT)

        enemy_panel = pygame.Rect(250, 70, 300, 190)
        pygame.draw.rect(game.screen, COLOR_PANEL, enemy_panel, border_radius=8)
        enemy = game.battle.first_alive_enemy()
        if enemy is not None:
            battle_frame = (pygame.time.get_ticks() // 180) % 4
            sprite = game.sprites.get(enemy_sprite_id(enemy.name), "down", battle_frame)
            sprite = pygame.transform.scale(sprite, (96, 96))
            enemy_rect = sprite.get_rect(center=(enemy_panel.centerx, enemy_panel.y + 86))
            pygame.draw.ellipse(game.screen, COLOR_BLACK, enemy_rect.inflate(-18, -74).move(0, 43))
            game.screen.blit(sprite, enemy_rect)
            draw_text_center(game.screen, enemy.name, enemy_panel.centerx, enemy_panel.y + 135, game.font, COLOR_TEXT)
            draw_bar(game.screen, enemy_panel.x + 55, enemy_panel.y + 162, 190, 12, enemy.hp, enemy.max_hp, COLOR_DANGER)

        party_panel = pygame.Rect(38, 305, 395, 156)
        command_panel = pygame.Rect(462, 305, 300, 156)
        log_panel = pygame.Rect(38, 480, 724, 92)
        pygame.draw.rect(game.screen, COLOR_PANEL, party_panel, border_radius=8)
        pygame.draw.rect(game.screen, COLOR_PANEL, command_panel, border_radius=8)
        pygame.draw.rect(game.screen, COLOR_PANEL, log_panel, border_radius=8)

        self.draw_party(party_panel)
        self.draw_commands(command_panel)
        self.draw_log(log_panel)

    def draw_party(self, panel: pygame.Rect) -> None:
        game = self.game
        y = panel.y + 24
        for index, member in enumerate(game.party):
            selected = index == game.battle.current_actor_index and game.state == STATE_BATTLE
            color = COLOR_TEXT if member.alive else COLOR_DANGER
            if selected and member.alive:
                pygame.draw.rect(game.screen, COLOR_PANEL_ALT, pygame.Rect(panel.x + 16, y - 8, panel.width - 32, 48), border_radius=6)
            draw_text(game.screen, member.name, panel.x + 28, y, game.font, color)
            draw_bar(game.screen, panel.x + 130, y + 2, 110, 10, member.hp, member.max_hp, COLOR_HP)
            draw_bar(game.screen, panel.x + 130, y + 22, 110, 8, member.mp, member.max_mp, COLOR_MP)
            draw_text(game.screen, f"{member.hp}/{member.max_hp}", panel.x + 254, y - 2, game.small_font, COLOR_TEXT)
            draw_text(game.screen, f"{member.mp}/{member.max_mp}", panel.x + 254, y + 18, game.small_font, COLOR_MUTED)
            y += 62

    def draw_commands(self, panel: pygame.Rect) -> None:
        game = self.game
        actor = None
        if game.battle.current_actor_index < len(game.party):
            actor = game.party[game.battle.current_actor_index]
        title = actor.name if actor and actor.alive else "コマンド"
        draw_text(game.screen, title, panel.x + 24, panel.y + 18, game.font, COLOR_TEXT)

        for index, command in enumerate(game.battle.commands):
            y = panel.y + 54 + index * 24
            selected = index == game.battle.command_index
            marker = ">" if selected else " "
            color = COLOR_TEXT if selected else COLOR_MUTED
            draw_text(game.screen, f"{marker} {command}", panel.x + 28, y, game.font, color)

    def draw_log(self, panel: pygame.Rect) -> None:
        game = self.game
        y = panel.y + 14
        for message in game.battle.log[-3:]:
            draw_text(game.screen, message, panel.x + 18, y, game.small_font, COLOR_TEXT)
            y += 24
