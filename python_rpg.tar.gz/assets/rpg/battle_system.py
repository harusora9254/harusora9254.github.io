from __future__ import annotations

import random

from rpg.constants import ENEMY_DATA
from rpg.models import BattleOutcome, Combatant, EnemySpot


class BattleSystem:
    def __init__(self, party: list[Combatant], inventory: dict[str, int]) -> None:
        self.party = party
        self.inventory = inventory
        self.commands = ["攻撃", "スキル", "アイテム", "防御"]
        self.command_index = 0
        self.current_actor_index = 0
        self.actions: list[tuple[Combatant, str]] = []
        self.log: list[str] = []
        self.sfx_events: list[str] = []
        self.current_enemy_spot: EnemySpot | None = None
        self.enemies: list[Combatant] = []

    def start(self, enemy_spot: EnemySpot) -> None:
        self.current_enemy_spot = enemy_spot
        self.enemies = [self.create_enemy(enemy_spot.kind)]
        self.actions = []
        self.log = [f"{enemy_spot.kind}が あらわれた！"]
        self.sfx_events = []
        self.current_actor_index = 0
        self.command_index = 0
        for member in self.party:
            member.guarding = False
        self.skip_unavailable_actors()

    def move_command(self, delta: int) -> None:
        self.command_index = (self.command_index + delta) % len(self.commands)

    def cancel_pending_action(self) -> bool:
        if not self.actions or self.current_actor_index <= 0:
            return False
        self.actions.pop()
        self.current_actor_index -= 1
        self.command_index = 0
        self.skip_unavailable_actors()
        return True

    def select_command(self) -> BattleOutcome | None:
        self.skip_unavailable_actors()
        if self.current_actor_index >= len(self.party):
            return self.resolve_turn()

        actor = self.party[self.current_actor_index]
        command = self.commands[self.command_index]

        if command == "スキル" and actor.mp < actor.skill_cost:
            self.add_log(f"{actor.name}の MPが 足りない。")
            return None
        if command == "アイテム" and self.inventory.get("薬草", 0) <= 0:
            self.add_log("薬草を 持っていない。")
            return None

        self.actions.append((actor, command))
        self.add_log(f"{actor.name}: {command}")
        self.sfx_events.append("confirm")
        self.current_actor_index += 1
        self.skip_unavailable_actors()
        self.command_index = 0

        if self.current_actor_index >= len(self.party):
            return self.resolve_turn()
        return None

    def create_enemy(self, kind: str) -> Combatant:
        data = ENEMY_DATA[kind]
        return Combatant(
            kind,
            data["max_hp"],
            data["max_hp"],
            0,
            0,
            data["attack"],
            data["defense"],
            data["speed"],
            "",
            0,
        )

    def skip_unavailable_actors(self) -> None:
        while (
            self.current_actor_index < len(self.party)
            and not self.party[self.current_actor_index].alive
        ):
            self.current_actor_index += 1

    def resolve_turn(self) -> BattleOutcome | None:
        for member in self.party:
            member.guarding = False

        for actor, command in self.actions:
            if not actor.alive:
                continue
            if not any(enemy.alive for enemy in self.enemies):
                break
            self.execute_player_action(actor, command)

        if not any(enemy.alive for enemy in self.enemies):
            return self.finish_victory()

        for enemy in self.enemies:
            if enemy.alive:
                living_members = [member for member in self.party if member.alive]
                target = random.choice(living_members)
                damage = self.calculate_damage(enemy, target)
                target.hp = max(0, target.hp - damage)
                self.add_log(f"{enemy.name}の攻撃！ {target.name}に{damage}ダメージ。")
                self.sfx_events.append("damage")

        for member in self.party:
            member.guarding = False

        if not any(member.alive for member in self.party):
            return self.finish_defeat()

        self.actions = []
        self.current_actor_index = 0
        self.command_index = 0
        self.skip_unavailable_actors()
        return None

    def execute_player_action(self, actor: Combatant, command: str) -> None:
        enemy = self.first_alive_enemy()
        if enemy is None:
            return

        if command == "攻撃":
            damage = self.calculate_damage(actor, enemy)
            enemy.hp = max(0, enemy.hp - damage)
            self.add_log(f"{actor.name}の攻撃！ {enemy.name}に{damage}ダメージ。")
            self.sfx_events.append("attack")
        elif command == "スキル":
            if actor.name == "僧侶":
                actor.spend_mp(actor.skill_cost)
                target = self.lowest_hp_party_member()
                healed = target.heal(30)
                self.add_log(f"{actor.name}はヒールを唱えた。{target.name}のHPが{healed}回復。")
                self.sfx_events.append("heal")
            else:
                actor.spend_mp(actor.skill_cost)
                damage = self.calculate_damage(actor, enemy, multiplier=1.8)
                enemy.hp = max(0, enemy.hp - damage)
                self.add_log(f"{actor.name}の{actor.skill_name}！ {damage}ダメージ。")
                self.sfx_events.append("attack")
        elif command == "アイテム":
            self.inventory["薬草"] -= 1
            target = self.lowest_hp_party_member()
            healed = target.heal(40)
            self.add_log(f"{actor.name}は薬草を使った。{target.name}のHPが{healed}回復。")
            self.sfx_events.append("heal")
        elif command == "防御":
            actor.guarding = True
            self.add_log(f"{actor.name}は身を守っている。")

    def calculate_damage(
        self, attacker: Combatant, defender: Combatant, multiplier: float = 1.0
    ) -> int:
        base = int(attacker.attack * multiplier) - defender.defense // 2
        damage = max(1, base)
        if defender.guarding:
            damage = max(1, damage // 2)
        return damage

    def first_alive_enemy(self) -> Combatant | None:
        for enemy in self.enemies:
            if enemy.alive:
                return enemy
        return None

    def lowest_hp_party_member(self) -> Combatant:
        living_members = [member for member in self.party if member.alive]
        return min(living_members, key=lambda member: member.hp / member.max_hp)

    def finish_victory(self) -> BattleOutcome:
        enemy_name = self.current_enemy_spot.kind if self.current_enemy_spot else "敵"
        exp = 0
        gold = 0
        if self.current_enemy_spot is not None:
            self.current_enemy_spot.defeated = True
            exp = ENEMY_DATA[self.current_enemy_spot.kind]["exp"]
            gold = 5
        self.enemies = []
        self.current_enemy_spot = None
        self.actions = []
        return BattleOutcome("victory", f"{enemy_name}を倒した！", exp, gold)

    def finish_defeat(self) -> BattleOutcome:
        for member in self.party:
            member.restore_all()
        self.enemies = []
        self.current_enemy_spot = None
        self.actions = []
        return BattleOutcome("defeat", "全滅した。プロトタイプ用に全回復して戻ります。")

    def add_log(self, message: str) -> None:
        self.log.append(message)
        self.log = self.log[-6:]

    def pop_sfx_events(self) -> list[str]:
        events = self.sfx_events
        self.sfx_events = []
        return events
