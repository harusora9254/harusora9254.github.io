from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
import random

from rpg.constants import ENEMY_DATA
from rpg.models import BattleOutcome, Combatant, EnemySpot, Skill

RESULT_STEP_WAIT_MS = 500
ENEMY_DEFEAT_FADE_MS = 900
CRITICAL_DAMAGE_MULTIPLIER = 3.0


@dataclass
class BattleResultStep:
    message: str
    wait_ms: int = RESULT_STEP_WAIT_MS
    sfx: str | None = None
    effect: Callable[[], None] | None = None


@dataclass
class BattleTurnAction:
    actor: Combatant
    command: str
    order: int
    is_enemy: bool = False


@dataclass
class DamageResult:
    damage: int = 0
    hit: bool = True
    critical: bool = False


class BattleSystem:
    def __init__(self, party: list[Combatant], inventory: dict[str, int]) -> None:
        self.party = party
        self.inventory = inventory
        self.commands = ["攻撃", "スキル", "アイテム", "防御"]
        self.command_index = 0
        self.current_actor_index = 0
        self.actions: list[tuple[Combatant, str]] = []
        self.log: list[str] = []
        self.sfx_events: list[str] = []
        self.current_enemy_spot: EnemySpot | None = None
        self.enemies: list[Combatant] = []
        self.defeated_enemy: Combatant | None = None
        self.enemy_defeat_fade_elapsed_ms = 0
        self.enemy_defeat_fade_duration_ms = ENEMY_DEFEAT_FADE_MS
        self.result_steps: list[BattleResultStep] = []
        self.result_wait_ms = 0
        self.pending_outcome_result: str | None = None

    @property
    def is_resolving(self) -> bool:
        return (
            self.result_wait_ms > 0
            or bool(self.result_steps)
            or self.pending_outcome_result is not None
        )

    def start(self, enemy_spot: EnemySpot) -> None:
        self.current_enemy_spot = enemy_spot
        self.enemies = [self.create_enemy(enemy_spot.kind)]
        self.defeated_enemy = None
        self.enemy_defeat_fade_elapsed_ms = 0
        self.actions = []
        self.log = [f"{enemy_spot.kind}が あらわれた！"]
        self.sfx_events = []
        self.result_steps = []
        self.result_wait_ms = 0
        self.pending_outcome_result = None
        self.current_actor_index = 0
        self.command_index = 0
        for member in self.party:
            member.guarding = False
        self.skip_unavailable_actors()

    def move_command(self, delta: int) -> None:
        if self.is_resolving:
            return
        self.command_index = (self.command_index + delta) % len(self.commands)

    def cancel_pending_action(self) -> bool:
        if self.is_resolving:
            return False
        if not self.actions or self.current_actor_index <= 0:
            return False
        self.actions.pop()
        self.current_actor_index -= 1
        self.command_index = 0
        self.skip_unavailable_actors()
        return True

    def select_command(self) -> BattleOutcome | None:
        if self.is_resolving:
            return None
        self.skip_unavailable_actors()
        if self.current_actor_index >= len(self.party):
            return self.resolve_turn()

        actor = self.party[self.current_actor_index]
        command = self.commands[self.command_index]

        if command == "スキル":
            skill = actor.primary_skill()
            if skill is None:
                self.add_log(f"{actor.name}は スキルを 覚えていない。")
                return None
            if actor.mp < skill.mp_cost:
                self.add_log(f"{actor.name}の MPが 足りない。")
                return None
        if command == "アイテム" and self.inventory.get("薬草", 0) <= 0:
            self.add_log("薬草を 持っていない。")
            return None

        self.actions.append((actor, command))
        self.add_log(f"{actor.name}: {command}")
        self.sfx_events.append("confirm")
        self.current_actor_index += 1
        self.skip_unavailable_actors()
        self.command_index = 0

        if self.current_actor_index >= len(self.party):
            return self.resolve_turn()
        return None

    def create_enemy(self, kind: str) -> Combatant:
        data = ENEMY_DATA[kind]
        max_hp = int(data["max_hp"])
        max_mp = int(data.get("max_mp", 0))
        return Combatant(
            kind,
            max_hp,
            max_hp,
            max_mp,
            max_mp,
            int(data["attack"]),
            int(data["defense"]),
            int(data["speed"]),
            "",
            0,
            magic_attack=data.get("magic_attack"),
            magic_defense=data.get("magic_defense"),
            luck=int(data.get("luck", 10)),
            hit_rate=float(data.get("hit_rate", 0.95)),
            evasion_rate=float(data.get("evasion_rate", 0.05)),
            critical_rate=float(data.get("critical_rate", 0.05)),
            critical_evasion_rate=float(data.get("critical_evasion_rate", 0.0)),
            target_rate=float(data.get("target_rate", 1.0)),
            element_resistances=data.get("element_resistances"),
            state_resistances=data.get("state_resistances"),
            skills=list(data.get("skills", [])),
            exp_reward=int(data.get("exp_reward", data.get("exp", 0))),
            gold_reward=int(data.get("gold_reward", 5)),
            drop_items=list(data.get("drop_items", [])),
        )

    def skip_unavailable_actors(self) -> None:
        while (
            self.current_actor_index < len(self.party)
            and not self.party[self.current_actor_index].alive
        ):
            self.current_actor_index += 1

    def resolve_turn(self) -> BattleOutcome | None:
        self.result_steps = []
        self.result_wait_ms = 0
        self.pending_outcome_result = None

        for member in self.party:
            member.guarding = False

        planned_hp = {
            id(combatant): combatant.hp for combatant in [*self.party, *self.enemies]
        }
        planned_guarding = {id(member): False for member in self.party}

        def planned_alive(combatant: Combatant) -> bool:
            return planned_hp[id(combatant)] > 0

        def set_planned_hp(combatant: Combatant, hp: int) -> None:
            planned_hp[id(combatant)] = max(0, min(combatant.max_hp, hp))

        def first_planned_alive_enemy() -> Combatant | None:
            for enemy in self.enemies:
                if planned_alive(enemy):
                    return enemy
            return None

        def lowest_planned_hp_party_member() -> Combatant:
            living_members = [member for member in self.party if planned_alive(member)]
            return min(living_members, key=lambda member: planned_hp[id(member)] / member.max_hp)

        def weighted_planned_target(candidates: list[Combatant]) -> Combatant | None:
            living_candidates = [candidate for candidate in candidates if planned_alive(candidate)]
            if not living_candidates:
                return None
            weights = [max(0.0, candidate.target_rate) for candidate in living_candidates]
            if sum(weights) <= 0:
                weights = [1.0 for _ in living_candidates]
            return random.choices(living_candidates, weights=weights, k=1)[0]

        for turn_action in self.turn_actions_by_speed():
            actor = turn_action.actor
            if not planned_alive(actor):
                continue
            if turn_action.is_enemy:
                target = weighted_planned_target(self.party)
                if target is None:
                    break
                result = self.roll_damage(actor, target, None, planned_guarding)
                self.queue_attack_result(actor, target, result)
                if result.hit:
                    set_planned_hp(target, planned_hp[id(target)] - result.damage)
                continue

            if not any(planned_alive(enemy) for enemy in self.enemies):
                break
            self.queue_player_result(
                actor,
                turn_action.command,
                planned_hp,
                planned_guarding,
                set_planned_hp,
                first_planned_alive_enemy,
                lowest_planned_hp_party_member,
            )

        if not any(planned_alive(member) for member in self.party):
            self.pending_outcome_result = "defeat"
            return self.begin_next_result_step()

        if not any(planned_alive(enemy) for enemy in self.enemies):
            defeated_enemy = next((enemy for enemy in self.enemies if not planned_alive(enemy)), None)
            if defeated_enemy is not None:
                self.queue_result_step(
                    f"{defeated_enemy.name}を倒した！",
                    wait_ms=ENEMY_DEFEAT_FADE_MS,
                )
            self.pending_outcome_result = "victory"
            return self.begin_next_result_step()

        self.begin_next_result_step()
        return None

    def turn_actions_by_speed(self) -> list[BattleTurnAction]:
        turn_actions = [
            BattleTurnAction(actor, command, order)
            for order, (actor, command) in enumerate(self.actions)
        ]
        enemy_order_offset = len(turn_actions)
        turn_actions.extend(
            BattleTurnAction(enemy, "攻撃", enemy_order_offset + order, is_enemy=True)
            for order, enemy in enumerate(self.enemies)
            if enemy.alive
        )
        return sorted(turn_actions, key=lambda action: (-action.actor.speed, action.order))

    def queue_player_result(
        self,
        actor: Combatant,
        command: str,
        planned_hp: dict[int, int],
        planned_guarding: dict[int, bool],
        set_planned_hp: Callable[[Combatant, int], None],
        first_planned_alive_enemy: Callable[[], Combatant | None],
        lowest_planned_hp_party_member: Callable[[], Combatant],
    ) -> None:
        if command == "攻撃":
            enemy = first_planned_alive_enemy()
            if enemy is None:
                return
            result = self.roll_damage(actor, enemy, None, planned_guarding)
            self.queue_attack_result(actor, enemy, result)
            if result.hit:
                set_planned_hp(enemy, planned_hp[id(enemy)] - result.damage)
        elif command == "スキル":
            skill = actor.primary_skill()
            if skill is None:
                self.queue_result_step(f"{actor.name}は スキルを 覚えていない。")
                return
            actor.spend_mp(skill.mp_cost)
            if skill.type == "heal":
                target = lowest_planned_hp_party_member()
                healed = min(self.calculate_heal_amount(actor, skill), target.max_hp - planned_hp[id(target)])
                set_planned_hp(target, planned_hp[id(target)] + healed)
                self.queue_heal_result(
                    f"{actor.name}は{skill.name}を唱えた。",
                    target,
                    healed,
                    "heal",
                )
                return
            if skill.type in {"physical", "magical"}:
                enemy = first_planned_alive_enemy()
                if enemy is None:
                    return
                result = self.roll_damage(actor, enemy, skill, planned_guarding)
                self.queue_result_step(f"{actor.name}の{skill.name}！")
                self.queue_damage_result(enemy, result)
                if result.hit:
                    set_planned_hp(enemy, planned_hp[id(enemy)] - result.damage)
                return
            self.queue_result_step(f"{actor.name}は{skill.name}を使った。")
        elif command == "アイテム":
            if self.inventory.get("薬草", 0) <= 0:
                self.queue_result_step("薬草を 持っていない。")
                return
            self.inventory["薬草"] -= 1
            target = lowest_planned_hp_party_member()
            healed = min(40, target.max_hp - planned_hp[id(target)])
            set_planned_hp(target, planned_hp[id(target)] + healed)
            self.queue_heal_result(
                f"{actor.name}は薬草を使った。",
                target,
                healed,
                "heal",
            )
        elif command == "防御":
            planned_guarding[id(actor)] = True
            self.queue_result_step(
                f"{actor.name}は身を守っている。",
                effect=lambda actor=actor: setattr(actor, "guarding", True),
            )

    def roll_damage(
        self,
        attacker: Combatant,
        target: Combatant,
        skill: Skill | None,
        planned_guarding: dict[int, bool],
    ) -> DamageResult:
        if self.is_miss(attacker, target):
            return DamageResult(hit=False)

        damage = self.calculate_damage(attacker, target, skill)
        if planned_guarding.get(id(target), False):
            damage = max(1, damage // 2)

        critical = self.is_critical(attacker, target)
        if critical:
            damage = max(1, int(damage * CRITICAL_DAMAGE_MULTIPLIER))
        return DamageResult(damage, True, critical)

    def calculate_damage(
        self, attacker: Combatant, target: Combatant, skill: Skill | None
    ) -> int:
        skill_power = skill.power if skill is not None else 1.0
        if skill is not None and skill.type == "magical":
            base = int(attacker.magic_attack) * 4 - int(target.magic_defense) * 2
        else:
            base = attacker.attack * 4 - target.defense * 2
        damage = max(1, int(base * skill_power))
        element = skill.element if skill is not None else "none"
        if element != "none":
            damage = int(damage * target.element_resistances.get(element, 1.0))
        return max(1, damage)

    def calculate_heal_amount(self, actor: Combatant, skill: Skill) -> int:
        return max(1, int((30 + int(actor.magic_attack)) * skill.power))

    def is_miss(self, attacker: Combatant, target: Combatant) -> bool:
        hit_chance = clamp(attacker.hit_rate - target.evasion_rate, 0.0, 1.0)
        return random.random() > hit_chance

    def is_critical(self, attacker: Combatant, target: Combatant) -> bool:
        critical_chance = (
            attacker.critical_rate
            + attacker.luck * 0.001
            - target.critical_evasion_rate
        )
        return random.random() < clamp(critical_chance, 0.0, 1.0)

    def adjusted_state_chance(
        self, attacker: Combatant, target: Combatant, state_id: str, base_chance: float
    ) -> float:
        luck_modifier = (attacker.luck - target.luck) * 0.001
        resistance = target.state_resistances.get(state_id, 1.0)
        return clamp((base_chance + luck_modifier) * resistance, 0.0, 1.0)

    def queue_attack_result(
        self, attacker: Combatant, target: Combatant, result: DamageResult
    ) -> None:
        self.queue_result_step(f"{attacker.name}の攻撃！")
        self.queue_damage_result(target, result)

    def queue_damage_result(self, target: Combatant, result: DamageResult) -> None:
        if not result.hit:
            self.queue_result_step(f"{target.name}は攻撃をかわした。", sfx="evade")
            return
        message = f"{target.name}は{result.damage}ダメージを受けた。"
        if result.critical:
            message = f"会心！ {message}"
        self.queue_result_step(
            message,
            sfx="attack_hit",
            effect=lambda target=target, damage=result.damage: self.apply_damage(target, damage),
        )

    def queue_heal_result(
        self, announce_message: str, target: Combatant, healed: int, sfx: str
    ) -> None:
        self.queue_result_step(announce_message)
        self.queue_result_step(
            f"{target.name}のHPが{healed}回復した。",
            sfx=sfx,
            effect=lambda target=target, healed=healed: self.apply_heal(target, healed),
        )

    def queue_result_step(
        self,
        message: str,
        wait_ms: int = RESULT_STEP_WAIT_MS,
        sfx: str | None = None,
        effect: Callable[[], None] | None = None,
    ) -> None:
        self.result_steps.append(BattleResultStep(message, wait_ms, sfx, effect))

    def begin_next_result_step(self) -> BattleOutcome | None:
        if self.result_steps:
            step = self.result_steps.pop(0)
            if step.effect is not None:
                step.effect()
            self.add_log(step.message)
            if step.sfx is not None:
                self.sfx_events.append(step.sfx)
            self.result_wait_ms = step.wait_ms
            return None
        return self.finish_result_phase()

    def update(self, dt_ms: int) -> BattleOutcome | None:
        self.update_enemy_defeat_fade(dt_ms)
        if not self.is_resolving:
            return None
        self.result_wait_ms = max(0, self.result_wait_ms - dt_ms)
        if self.result_wait_ms > 0:
            return None
        return self.begin_next_result_step()

    def finish_result_phase(self) -> BattleOutcome | None:
        self.result_wait_ms = 0
        if self.pending_outcome_result == "victory":
            self.pending_outcome_result = None
            return self.finish_victory()
        if self.pending_outcome_result == "defeat":
            self.pending_outcome_result = None
            return self.finish_defeat()

        for member in self.party:
            member.guarding = False
        self.actions = []
        self.current_actor_index = 0
        self.command_index = 0
        self.skip_unavailable_actors()
        return None

    def apply_damage(self, target: Combatant, damage: int) -> None:
        was_alive = target.alive
        target.hp = max(0, target.hp - damage)
        if was_alive and not target.alive and target in self.enemies:
            self.start_enemy_defeat_fade(target)

    def apply_heal(self, target: Combatant, healed: int) -> None:
        target.hp = min(target.max_hp, target.hp + healed)

    def start_enemy_defeat_fade(self, enemy: Combatant) -> None:
        self.defeated_enemy = enemy
        self.enemy_defeat_fade_elapsed_ms = 0
        self.sfx_events.append("damage")

    def update_enemy_defeat_fade(self, dt_ms: int) -> None:
        if self.defeated_enemy is None:
            return
        self.enemy_defeat_fade_elapsed_ms = min(
            self.enemy_defeat_fade_duration_ms,
            self.enemy_defeat_fade_elapsed_ms + dt_ms,
        )

    @property
    def enemy_defeat_alpha(self) -> int:
        if self.defeated_enemy is None:
            return 255
        progress = self.enemy_defeat_fade_elapsed_ms / max(1, self.enemy_defeat_fade_duration_ms)
        return max(0, min(255, int(255 * (1.0 - progress))))

    def display_enemy(self) -> Combatant | None:
        alive_enemy = self.first_alive_enemy()
        if alive_enemy is not None:
            return alive_enemy
        if self.enemy_defeat_alpha > 0:
            return self.defeated_enemy
        return None

    def first_alive_enemy(self) -> Combatant | None:
        for enemy in self.enemies:
            if enemy.alive:
                return enemy
        return None

    def finish_victory(self) -> BattleOutcome:
        enemy_name = self.current_enemy_spot.kind if self.current_enemy_spot else "敵"
        exp = 0
        gold = 0
        defeated_enemy = self.enemies[0] if self.enemies else None
        if self.current_enemy_spot is not None:
            self.current_enemy_spot.defeated = True
            fallback_data = ENEMY_DATA[self.current_enemy_spot.kind]
            exp = (
                defeated_enemy.exp_reward
                if defeated_enemy is not None
                else int(fallback_data.get("exp_reward", fallback_data.get("exp", 0)))
            )
            gold = (
                defeated_enemy.gold_reward
                if defeated_enemy is not None
                else int(fallback_data.get("gold_reward", 5))
            )
        self.enemies = []
        self.defeated_enemy = None
        self.current_enemy_spot = None
        self.actions = []
        return BattleOutcome("victory", f"{enemy_name}を倒した！", exp, gold)

    def finish_defeat(self) -> BattleOutcome:
        for member in self.party:
            member.restore_all()
        self.enemies = []
        self.defeated_enemy = None
        self.current_enemy_spot = None
        self.actions = []
        return BattleOutcome("defeat", "全滅した。プロトタイプ用に全回復して戻ります。")

    def add_log(self, message: str) -> None:
        self.log.append(message)
        self.log = self.log[-6:]

    def pop_sfx_events(self) -> list[str]:
        events = self.sfx_events
        self.sfx_events = []
        return events


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(value, maximum))
