﻿from __future__ import annotations

import asyncio
import random
import sys

import pygame

from rpg.audio_manager import AudioManager, pre_init_mixer
from rpg.battle_system import BattleSystem
from rpg.battle_screen import BattleScreen
from rpg.constants import (
    BLOCKED_TILES,
    COLOR_BLACK,
    COLOR_PANEL,
    COLOR_PANEL_ALT,
    COLOR_TEXT,
    FPS,
    PLAYER_MOVE_DURATION_MS,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    STATE_BATTLE,
    STATE_MAP,
    STATE_MENU,
    SYMBOL_MOVE_DURATION_MS,
    SYMBOL_MOVE_WAIT_MAX_MS,
    SYMBOL_MOVE_WAIT_MIN_MS,
    TILE_SIZE,
    VIEWPORT_HEIGHT,
    VIEWPORT_WIDTH,
)
from rpg.fonts import load_font
from rpg.map_loader import load_map
from rpg.map_screen import MapScreen
from rpg.menu_screen import MenuScreen
from rpg.models import BattleOutcome, Combatant, EnemySpot, GameMap, NPC
from rpg.character_sprites import SpriteFactory
from rpg.screen_utils import draw_text_center
from rpg.tile_images import TileSet
from rpg.virtual_controller import VirtualController, current_mobile_mode, display_size_for_mode

DIRECTION_KEYS = {
    pygame.K_UP: (0, -1),
    pygame.K_w: (0, -1),
    pygame.K_DOWN: (0, 1),
    pygame.K_s: (0, 1),
    pygame.K_LEFT: (-1, 0),
    pygame.K_a: (-1, 0),
    pygame.K_RIGHT: (1, 0),
    pygame.K_d: (1, 0),
}

HELD_DIRECTION_ORDER = [
    ((0, -1), (pygame.K_UP, pygame.K_w)),
    ((0, 1), (pygame.K_DOWN, pygame.K_s)),
    ((-1, 0), (pygame.K_LEFT, pygame.K_a)),
    ((1, 0), (pygame.K_RIGHT, pygame.K_d)),
]

CONFIRM_KEYS = (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE)
CANCEL_KEYS = (pygame.K_x, pygame.K_BACKSPACE, pygame.K_DELETE)

AUTO_PAUSE_EVENT_TYPES = tuple(
    getattr(pygame, name)
    for name in ("WINDOWFOCUSLOST", "WINDOWMINIMIZED", "WINDOWHIDDEN")
    if hasattr(pygame, name)
)


class RPGPrototype:
    def __init__(self) -> None:
        pre_init_mixer()
        pygame.init()
        pygame.display.set_caption("Python RPG Prototype")
        self.display_size = display_size_for_mode(current_mobile_mode())
        self.display_surface = pygame.display.set_mode(self.display_size)
        self.game_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)).convert()
        self.screen = self.game_surface
        self.clock = pygame.time.Clock()
        self.font = load_font(22)
        self.small_font = load_font(18)
        self.big_font = load_font(36)
        self.sprites = SpriteFactory()
        self.tiles = TileSet()
        self.audio = AudioManager()
        self.map_screen = MapScreen(self)
        self.menu_screen = MenuScreen(self)
        self.battle_screen = BattleScreen(self)

        self.running = True
        self.shutdown_complete = False
        self.paused = False
        self.pause_reason = ""
        self.play_time_ms = 0
        self.browser_pause_requested = False
        self.browser_pause_proxy = None
        self.state = STATE_MAP
        self.maps: dict[str, GameMap] = {}
        self.current_map = self.get_map("village")

        self.player_x = self.current_map.start_x
        self.player_y = self.current_map.start_y
        self.player_visual_x = float(self.player_x)
        self.player_visual_y = float(self.player_y)
        self.player_start_x = self.player_x
        self.player_start_y = self.player_y
        self.player_target_x = self.player_x
        self.player_target_y = self.player_y
        self.player_move_elapsed_ms = 0
        self.player_moving = False

        self.facing_dx = 0
        self.facing_dy = 1
        self.last_direction = (0, 1)
        self.camera_x = 0.0
        self.camera_y = 0.0
        self.map_message = "村を探索中。Z/Enter/Spaceで会話できます。"

        self.dialog_speaker: str | None = None
        self.dialog_pages: list[str] = []
        self.dialog_index = 0

        self.party = [
            Combatant(
                "勇者",
                120,
                120,
                20,
                20,
                18,
                12,
                12,
                "強撃",
                3,
                magic_attack=12,
                magic_defense=10,
                luck=12,
                skills=[
                    {
                        "name": "強撃",
                        "mp_cost": 3,
                        "power": 1.5,
                        "type": "physical",
                        "element": "none",
                        "target": "enemy",
                    }
                ],
            ),
            Combatant(
                "僧侶",
                90,
                90,
                35,
                35,
                10,
                9,
                14,
                "ヒール",
                4,
                magic_attack=18,
                magic_defense=14,
                luck=14,
                skills=[
                    {
                        "name": "ヒール",
                        "mp_cost": 4,
                        "power": 1.2,
                        "type": "heal",
                        "element": "light",
                        "target": "ally",
                    }
                ],
            ),
        ]
        self.inventory = {"薬草": 3}
        self.gold = 0
        self.exp = 0

        self.menu_items = ["ステータス", "アイテム", "戻る"]
        self.menu_index = 0
        self.menu_mode = "main"
        self.status_member_index = 0
        self.item_index = 0
        self.pending_battle_outcome: BattleOutcome | None = None
        self.battle = BattleSystem(self.party, self.inventory)
        self.virtual_direction: tuple[int, int] | None = None
        self.virtual_controller = VirtualController(self)
        self.defer_audio_until_input = sys.platform == "emscripten"
        self.audio_unlocked = not self.defer_audio_until_input
        self.pending_bgm: tuple[str, bool] | None = None
        self.install_browser_pause_handlers()
        self.update_camera()
        self.play_map_bgm(self.current_map.map_id)

    def get_map(self, map_id: str) -> GameMap:
        if map_id not in self.maps:
            self.maps[map_id] = load_map(map_id)
        return self.maps[map_id]

    def change_map(
        self,
        map_id: str,
        player_x: int | None = None,
        player_y: int | None = None,
        message: str = "",
    ) -> None:
        self.current_map = self.get_map(map_id)
        self.player_x = self.current_map.start_x if player_x is None else player_x
        self.player_y = self.current_map.start_y if player_y is None else player_y
        self.sync_player_visual()
        self.player_moving = False
        self.map_message = message or f"{self.current_map.name}に移動しました。"
        self.close_dialog()
        self.update_camera()
        self.play_map_bgm(self.current_map.map_id)

    async def run(self) -> None:
        while self.running:
            dt_ms = self.clock.tick(FPS)
            self.handle_events()
            self.handle_browser_pause_request()
            if not self.running:
                break
            self.update(dt_ms)
            self.draw()
            await asyncio.sleep(0)
        self.shutdown()

    def play_bgm(self, bgm_id: str) -> None:
        if self.defer_audio_until_input and not self.audio_unlocked:
            self.pending_bgm = (bgm_id, False)
            return
        self.pending_bgm = None
        self.audio.play_bgm(bgm_id)

    def play_map_bgm(self, map_id: str) -> None:
        if self.defer_audio_until_input and not self.audio_unlocked:
            self.pending_bgm = (map_id, True)
            return
        self.pending_bgm = None
        self.audio.play_map_bgm(map_id)

    def unlock_audio(self) -> None:
        if self.audio_unlocked:
            return
        self.audio_unlocked = True
        if self.pending_bgm is None:
            return
        bgm_id, is_map_bgm = self.pending_bgm
        self.pending_bgm = None
        if is_map_bgm:
            self.audio.play_map_bgm(bgm_id)
        else:
            self.audio.play_bgm(bgm_id)

    def is_audio_gesture(self, event: pygame.event.Event) -> bool:
        return event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN)

    def run_smoke_test(self) -> None:
        self.draw()
        self.state = STATE_MENU
        self.draw()
        self.change_map("random_dungeon", 4, 4, "スモークテスト: ランダム洞窟")
        self.draw()
        self.change_map("symbol_dungeon", 4, 4, "スモークテスト: シンボル洞窟")
        self.battle.start(self.current_map.enemies[0])
        self.state = STATE_BATTLE
        self.draw()
        self.shutdown()

    def handle_events(self) -> None:
        for event in pygame.event.get():
            if self.is_auto_pause_event(event):
                self.pause("TAB INACTIVE")
            if self.is_audio_gesture(event):
                self.unlock_audio()
            if self.virtual_controller.handle_event(event):
                continue
            if event.type == pygame.QUIT:
                self.request_quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.request_quit()
                    continue
                if event.key == pygame.K_p:
                    self.toggle_pause()
                    continue
                if self.paused:
                    continue
                if event.key in DIRECTION_KEYS:
                    self.last_direction = DIRECTION_KEYS[event.key]
                if self.state == STATE_MAP:
                    self.handle_map_key(event.key)
                elif self.state == STATE_MENU:
                    self.handle_menu_key(event.key)
                elif self.state == STATE_BATTLE:
                    self.handle_battle_key(event.key)

    def update(self, dt_ms: int) -> None:
        if self.paused:
            return
        self.play_time_ms += dt_ms
        if self.state == STATE_BATTLE:
            if self.pending_battle_outcome is not None:
                return
            outcome = self.battle.update(dt_ms)
            self.play_battle_sfx_events()
            if outcome is not None:
                self.present_battle_outcome(outcome)
            return
        if self.state != STATE_MAP:
            return
        self.update_player_movement(dt_ms)
        if self.state != STATE_MAP:
            return
        self.update_symbol_enemies(dt_ms)
        if self.state != STATE_MAP:
            return
        self.update_camera()

    def handle_map_key(self, key: int) -> None:
        if self.dialog_pages:
            if key in CONFIRM_KEYS:
                self.advance_dialog()
                self.audio.play_se("talk")
            elif key in CANCEL_KEYS:
                self.close_dialog()
                self.audio.play_se("cancel")
            return

        if key == pygame.K_q:
            self.request_quit()
        elif key in CANCEL_KEYS:
            self.open_menu()
        elif key in CONFIRM_KEYS:
            self.try_talk()

    def handle_menu_key(self, key: int) -> None:
        if key in CANCEL_KEYS:
            self.cancel_menu_selection()
            return
        if key in (pygame.K_UP, pygame.K_w):
            self.move_menu_selection(-1)
        elif key in (pygame.K_DOWN, pygame.K_s):
            self.move_menu_selection(1)
        elif key in CONFIRM_KEYS:
            self.confirm_menu_selection()

    def handle_battle_key(self, key: int) -> None:
        if self.pending_battle_outcome is not None:
            if key in CONFIRM_KEYS:
                self.finish_battle(self.pending_battle_outcome)
            return
        if not self.battle.enemies:
            return
        if self.battle.is_resolving:
            return
        if key in (pygame.K_UP, pygame.K_w):
            self.battle.move_command(-1)
            self.audio.play_se("cursor")
        elif key in (pygame.K_DOWN, pygame.K_s):
            self.battle.move_command(1)
            self.audio.play_se("cursor")
        elif key in CONFIRM_KEYS:
            self.confirm_battle_command()
        elif key in CANCEL_KEYS:
            self.cancel_battle_command()

    def handle_virtual_direction_press(self, direction: tuple[int, int]) -> None:
        if self.paused:
            return
        self.last_direction = direction
        if self.state == STATE_MAP:
            self.virtual_direction = direction
        elif self.state == STATE_MENU:
            if direction[1] < 0:
                self.move_menu_selection(-1)
            elif direction[1] > 0:
                self.move_menu_selection(1)
        elif self.state == STATE_BATTLE:
            if self.battle.is_resolving:
                return
            if direction[1] < 0:
                self.battle.move_command(-1)
                self.audio.play_se("cursor")
            elif direction[1] > 0:
                self.battle.move_command(1)
                self.audio.play_se("cursor")

    def handle_virtual_direction_release(self, direction: tuple[int, int]) -> None:
        if self.virtual_direction == direction:
            self.virtual_direction = None

    def handle_virtual_button(self, button: str) -> None:
        if self.paused:
            return
        if button == "a":
            self.confirm_virtual_action()
        elif button == "b":
            self.cancel_virtual_action()

    def confirm_virtual_action(self) -> None:
        if self.state == STATE_MAP:
            if self.dialog_pages:
                self.advance_dialog()
                self.audio.play_se("talk")
            else:
                self.try_talk()
        elif self.state == STATE_MENU:
            self.confirm_menu_selection()
        elif self.state == STATE_BATTLE:
            if self.pending_battle_outcome is not None:
                self.finish_battle(self.pending_battle_outcome)
                return
            self.confirm_battle_command()

    def cancel_virtual_action(self) -> None:
        if self.state == STATE_MAP:
            if self.dialog_pages:
                self.close_dialog()
                self.audio.play_se("cancel")
            else:
                self.open_menu()
        elif self.state == STATE_MENU:
            self.cancel_menu_selection()
        elif self.state == STATE_BATTLE:
            self.cancel_battle_command()

    def open_menu(self) -> None:
        self.state = STATE_MENU
        self.menu_index = 0
        self.menu_mode = "main"
        self.status_member_index = 0
        self.item_index = 0
        self.virtual_direction = None
        self.audio.play_se("confirm")

    def close_menu(self) -> None:
        self.state = STATE_MAP
        self.menu_mode = "main"
        self.status_member_index = 0
        self.item_index = 0
        self.virtual_direction = None
        self.audio.play_se("cancel")

    def move_menu_selection(self, delta: int) -> None:
        if self.menu_mode in {"status_list", "status_detail"}:
            self.status_member_index = (self.status_member_index + delta) % len(self.party)
        elif self.menu_mode == "item_list":
            if not self.inventory:
                return
            self.item_index = (self.item_index + delta) % len(self.inventory)
        else:
            self.menu_index = (self.menu_index + delta) % len(self.menu_items)
        self.audio.play_se("cursor")

    def confirm_menu_selection(self) -> None:
        if self.menu_mode == "status_list":
            self.menu_mode = "status_detail"
            self.audio.play_se("confirm")
            return
        if self.menu_mode == "status_detail":
            return
        if self.menu_mode == "item_list":
            return

        selected_item = self.menu_items[self.menu_index]
        if selected_item == "ステータス":
            self.menu_mode = "status_list"
            self.status_member_index = 0
            self.audio.play_se("confirm")
        elif selected_item == "アイテム":
            self.menu_mode = "item_list"
            self.item_index = 0
            self.audio.play_se("confirm")
        elif selected_item == "戻る":
            self.state = STATE_MAP
            self.menu_mode = "main"
            self.virtual_direction = None
            self.audio.play_se("confirm")

    def cancel_menu_selection(self) -> None:
        if self.menu_mode == "status_detail":
            self.menu_mode = "status_list"
            self.status_member_index = 0
            self.audio.play_se("cancel")
        elif self.menu_mode == "status_list":
            self.menu_mode = "main"
            self.status_member_index = 0
            self.audio.play_se("cancel")
        elif self.menu_mode == "item_list":
            self.menu_mode = "main"
            self.item_index = 0
            self.audio.play_se("cancel")
        else:
            self.close_menu()

    def confirm_battle_command(self) -> None:
        if self.battle.is_resolving:
            return
        outcome = self.battle.select_command()
        self.play_battle_sfx_events()
        if outcome is not None:
            self.finish_battle(outcome)

    def cancel_battle_command(self) -> None:
        if self.battle.cancel_pending_action():
            self.audio.play_se("cancel")

    def update_player_movement(self, dt_ms: int) -> None:
        if self.player_moving:
            self.player_move_elapsed_ms += dt_ms
            progress = min(1.0, self.player_move_elapsed_ms / PLAYER_MOVE_DURATION_MS)
            self.player_visual_x = lerp(self.player_start_x, self.player_target_x, progress)
            self.player_visual_y = lerp(self.player_start_y, self.player_target_y, progress)
            if progress >= 1.0:
                self.player_x = self.player_target_x
                self.player_y = self.player_target_y
                self.sync_player_visual()
                self.player_moving = False
                self.on_player_step_completed()
            return

        if self.dialog_pages:
            return

        direction = self.virtual_direction or self.held_direction()
        if direction is not None:
            self.start_player_move(*direction)

    def held_direction(self) -> tuple[int, int] | None:
        pressed = pygame.key.get_pressed()
        if is_direction_pressed(pressed, self.last_direction):
            return self.last_direction
        for direction, keys in HELD_DIRECTION_ORDER:
            if any(pressed[key] for key in keys):
                self.last_direction = direction
                return direction
        return None

    def start_player_move(self, dx: int, dy: int) -> None:
        self.facing_dx = dx
        self.facing_dy = dy
        next_x = self.player_x + dx
        next_y = self.player_y + dy

        enemy_spot = self.current_map.enemy_targeting(next_x, next_y)
        if enemy_spot is not None:
            self.start_battle(enemy_spot)
            return

        if not self.is_walkable(next_x, next_y):
            self.map_message = "進めません。"
            return

        self.player_start_x = self.player_x
        self.player_start_y = self.player_y
        self.player_target_x = next_x
        self.player_target_y = next_y
        self.player_move_elapsed_ms = 0
        self.player_moving = True

    def on_player_step_completed(self) -> None:
        map_exit = self.current_map.exit_at(self.player_x, self.player_y)
        if map_exit is not None:
            self.change_map(
                map_exit.target,
                map_exit.target_x,
                map_exit.target_y,
                map_exit.message,
            )
            return

        self.map_message = f"{self.current_map.name}: {self.player_x}, {self.player_y}"
        if self.current_map.encounter_type == "random":
            self.try_random_encounter()

    def try_random_encounter(self) -> None:
        if not self.current_map.random_encounters:
            return
        if random.random() >= self.current_map.encounter_rate:
            return
        kind = random.choice(self.current_map.random_encounters)
        enemy_spot = EnemySpot(self.player_x, self.player_y, kind)
        enemy_spot.visual_x = float(enemy_spot.x)
        enemy_spot.visual_y = float(enemy_spot.y)
        self.start_battle(enemy_spot)

    def update_symbol_enemies(self, dt_ms: int) -> None:
        if self.current_map.encounter_type != "symbol" or self.dialog_pages:
            return
        for enemy in self.current_map.enemies:
            if enemy.defeated:
                continue
            if enemy.moving:
                self.update_symbol_enemy_move(enemy, dt_ms)
            else:
                enemy.wait_ms -= dt_ms
                if enemy.wait_ms <= 0:
                    self.try_start_symbol_enemy_move(enemy)
            if self.state != STATE_MAP:
                return

    def update_symbol_enemy_move(self, enemy: EnemySpot, dt_ms: int) -> None:
        enemy.move_elapsed_ms += dt_ms
        progress = min(1.0, enemy.move_elapsed_ms / enemy.move_duration_ms)
        enemy.visual_x = lerp(enemy.start_x, enemy.target_x, progress)
        enemy.visual_y = lerp(enemy.start_y, enemy.target_y, progress)
        if progress < 1.0:
            return
        enemy.x = enemy.target_x
        enemy.y = enemy.target_y
        enemy.visual_x = float(enemy.x)
        enemy.visual_y = float(enemy.y)
        enemy.moving = False
        enemy.wait_ms = random.randint(SYMBOL_MOVE_WAIT_MIN_MS, SYMBOL_MOVE_WAIT_MAX_MS)
        if enemy.x == self.player_x and enemy.y == self.player_y:
            self.start_battle(enemy)

    def try_start_symbol_enemy_move(self, enemy: EnemySpot) -> None:
        if enemy.move_style != "random":
            enemy.wait_ms = random.randint(SYMBOL_MOVE_WAIT_MIN_MS, SYMBOL_MOVE_WAIT_MAX_MS)
            return

        directions = [(0, -1), (0, 1), (-1, 0), (1, 0), (0, 0)]
        random.shuffle(directions)
        for dx, dy in directions:
            if dx == 0 and dy == 0:
                break
            target_x = enemy.x + dx
            target_y = enemy.y + dy
            if target_x == self.player_x and target_y == self.player_y:
                self.start_battle(enemy)
                return
            if self.can_enemy_move_to(enemy, target_x, target_y):
                enemy.start_x = enemy.x
                enemy.start_y = enemy.y
                enemy.target_x = target_x
                enemy.target_y = target_y
                enemy.facing_dx = dx
                enemy.facing_dy = dy
                enemy.move_elapsed_ms = 0
                enemy.move_duration_ms = SYMBOL_MOVE_DURATION_MS
                enemy.moving = True
                return
        enemy.wait_ms = random.randint(SYMBOL_MOVE_WAIT_MIN_MS, SYMBOL_MOVE_WAIT_MAX_MS)

    def can_enemy_move_to(self, enemy: EnemySpot, x: int, y: int) -> bool:
        if x < 0 or y < 0 or x >= self.current_map.width or y >= self.current_map.height:
            return False
        if self.current_map.tile_at(x, y) in BLOCKED_TILES:
            return False
        if self.current_map.npc_at(x, y) is not None:
            return False
        if self.current_map.exit_at(x, y) is not None:
            return False
        for other in self.current_map.enemies:
            if other is enemy or other.defeated:
                continue
            if other.x == x and other.y == y:
                return False
            if other.moving and other.target_x == x and other.target_y == y:
                return False
        return True

    def is_walkable(self, x: int, y: int) -> bool:
        if x < 0 or y < 0 or x >= self.current_map.width or y >= self.current_map.height:
            return False
        if self.current_map.tile_at(x, y) in BLOCKED_TILES:
            return False
        if self.current_map.npc_at(x, y) is not None:
            return False
        return True

    def try_talk(self) -> None:
        target_x = self.player_x + self.facing_dx
        target_y = self.player_y + self.facing_dy
        npc = self.current_map.npc_at(target_x, target_y)
        if npc is None:
            self.map_message = "そこには誰もいません。"
            self.audio.play_se("cancel")
            return
        self.open_dialog(npc)
        self.audio.play_se("talk")

    def open_dialog(self, npc: NPC) -> None:
        self.dialog_speaker = npc.name
        self.dialog_pages = npc.dialog
        self.dialog_index = 0

    def advance_dialog(self) -> None:
        if self.dialog_index + 1 >= len(self.dialog_pages):
            self.close_dialog()
        else:
            self.dialog_index += 1

    def close_dialog(self) -> None:
        self.dialog_speaker = None
        self.dialog_pages = []
        self.dialog_index = 0

    def start_battle(self, enemy_spot: EnemySpot) -> None:
        self.player_moving = False
        self.sync_player_visual()
        self.pending_battle_outcome = None
        self.battle.start(enemy_spot)
        self.state = STATE_BATTLE
        self.audio.play_se("battle_start")
        self.play_bgm("battle")

    def present_battle_outcome(self, outcome: BattleOutcome) -> None:
        if outcome.result == "victory":
            self.exp += outcome.exp
            self.gold += outcome.gold
            self.audio.play_me("victory")
            self.pending_battle_outcome = outcome
            return
        self.finish_battle(outcome)

    def finish_battle(self, outcome: BattleOutcome) -> None:
        self.map_message = outcome.message
        self.pending_battle_outcome = None
        self.state = STATE_MAP
        self.update_camera()
        self.play_map_bgm(self.current_map.map_id)

    def play_battle_sfx_events(self) -> None:
        for sound_id in self.battle.pop_sfx_events():
            self.audio.play_se(sound_id)

    def sync_player_visual(self) -> None:
        self.player_visual_x = float(self.player_x)
        self.player_visual_y = float(self.player_y)
        self.player_start_x = self.player_x
        self.player_start_y = self.player_y
        self.player_target_x = self.player_x
        self.player_target_y = self.player_y

    def update_camera(self) -> None:
        world_width = self.current_map.width * TILE_SIZE
        world_height = self.current_map.height * TILE_SIZE
        player_center_x = self.player_visual_x * TILE_SIZE + TILE_SIZE // 2
        player_center_y = self.player_visual_y * TILE_SIZE + TILE_SIZE // 2
        max_camera_x = max(0, world_width - VIEWPORT_WIDTH)
        max_camera_y = max(0, world_height - VIEWPORT_HEIGHT)
        self.camera_x = clamp(player_center_x - VIEWPORT_WIDTH // 2, 0, max_camera_x)
        self.camera_y = clamp(player_center_y - VIEWPORT_HEIGHT // 2, 0, max_camera_y)

    def draw(self) -> None:
        if self.state == STATE_MAP:
            self.map_screen.draw()
        elif self.state == STATE_MENU:
            self.menu_screen.draw()
        elif self.state == STATE_BATTLE:
            self.battle_screen.draw()
        self.compose_display()

    def compose_display(self) -> None:
        self.ensure_display_layout()
        self.display_surface.fill(COLOR_BLACK)
        game_rect = self.virtual_controller.game_rect()
        if game_rect.size == self.game_surface.get_size():
            self.display_surface.blit(self.game_surface, game_rect)
        else:
            scaled_game = pygame.transform.smoothscale(self.game_surface, game_rect.size)
            self.display_surface.blit(scaled_game, game_rect)
            pygame.draw.rect(self.display_surface, COLOR_PANEL_ALT, game_rect, 2)
        if self.paused:
            self.draw_pause_overlay(game_rect)
        self.virtual_controller.draw()
        pygame.display.flip()

    def draw_pause_overlay(self, game_rect: pygame.Rect) -> None:
        overlay = pygame.Surface(self.display_surface.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        self.display_surface.blit(overlay, (0, 0))

        panel = pygame.Rect(0, 0, 280, 104)
        panel.center = game_rect.center
        pygame.draw.rect(self.display_surface, COLOR_BLACK, panel.move(4, 4), border_radius=8)
        pygame.draw.rect(self.display_surface, COLOR_PANEL, panel, border_radius=8)
        pygame.draw.rect(self.display_surface, COLOR_PANEL_ALT, panel, 2, border_radius=8)
        draw_text_center(
            self.display_surface,
            "PAUSED",
            panel.centerx,
            panel.y + 34,
            self.big_font,
            COLOR_TEXT,
        )
        label = "Press P or RESUME"
        if self.pause_reason == "TAB INACTIVE":
            label = "Paused while inactive"
        draw_text_center(
            self.display_surface,
            label,
            panel.centerx,
            panel.y + 76,
            self.small_font,
            COLOR_TEXT,
        )

    def ensure_display_layout(self) -> None:
        desired_size = display_size_for_mode(current_mobile_mode())
        if desired_size == self.display_size:
            return
        self.display_size = desired_size
        self.display_surface = pygame.display.set_mode(self.display_size)

    def toggle_pause(self) -> None:
        if self.paused:
            self.resume_pause()
        else:
            self.pause("PAUSED")

    def pause(self, reason: str = "PAUSED") -> None:
        if not self.paused:
            self.paused = True
        self.pause_reason = reason
        self.virtual_direction = None
        self.virtual_controller.release_all()
        self.audio.pause_music()

    def resume_pause(self) -> None:
        if not self.paused:
            return
        self.paused = False
        self.pause_reason = ""
        self.clock.tick(FPS)
        self.audio.resume_music()

    def install_browser_pause_handlers(self) -> None:
        if sys.platform != "emscripten":
            return
        try:
            from platform import document, window
            from pyodide.ffi import create_proxy

            self.browser_pause_proxy = create_proxy(self.request_browser_pause)
            for event_name in ("blur", "pagehide", "beforeunload"):
                window.addEventListener(event_name, self.browser_pause_proxy)
            document.addEventListener("visibilitychange", self.browser_pause_proxy)
        except (ImportError, AttributeError, TypeError):
            self.browser_pause_proxy = None

    def request_browser_pause(self, event: object | None = None) -> None:
        self.browser_pause_requested = True
        self.audio.pause_music()

    def handle_browser_pause_request(self) -> None:
        if self.browser_pause_requested:
            self.browser_pause_requested = False
            self.pause("TAB INACTIVE")
        elif browser_document_hidden():
            self.pause("TAB INACTIVE")

    def is_auto_pause_event(self, event: pygame.event.Event) -> bool:
        if event.type in AUTO_PAUSE_EVENT_TYPES:
            return True
        if hasattr(pygame, "ACTIVEEVENT") and event.type == pygame.ACTIVEEVENT:
            return getattr(event, "gain", 1) == 0
        return False

    def request_quit(self) -> None:
        self.running = False
        self.audio.stop_all()

    def shutdown(self) -> None:
        if self.shutdown_complete:
            return
        self.shutdown_complete = True
        self.audio.stop_all()
        pygame.quit()


def is_direction_pressed(pressed: pygame.key.ScancodeWrapper, direction: tuple[int, int]) -> bool:
    for candidate, keys in HELD_DIRECTION_ORDER:
        if candidate == direction:
            return any(pressed[key] for key in keys)
    return False


def browser_document_hidden() -> bool:
    if sys.platform != "emscripten":
        return False
    try:
        from platform import document

        return bool(document.hidden)
    except (ImportError, AttributeError, TypeError):
        return False


def lerp(start: float, end: float, progress: float) -> float:
    return start + (end - start) * progress


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))
