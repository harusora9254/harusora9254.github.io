"""Small RPG prototype package."""
